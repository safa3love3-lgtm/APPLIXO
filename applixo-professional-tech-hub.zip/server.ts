import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const TARGET_DOMAIN = process.env.SITE_BASE_URL || 'https://applixo.com';

const SITEMAP_PATHS = [
  '/',
  '/about',
  '/apps',
  '/apps/applixo-bizpulse-erp',
  '/apps/applixo-nexus-ai',
  '/apps/applixo-cinecut-pro',
  '/apps/applixo-krypton-chat',
  '/apps/applixo-aural-master',
  '/apps/applixo-focusflow-tasks',
  '/apps/applixo-smartkit-scan',
  '/apps/applixo-codelingo-edu',
  '/portfolio',
  '/services',
  '/testimonials',
  '/custom-development',
  '/contact',
  '/privacy-policy',
  '/terms-of-use',
];

function resolveBaseUrl(req: express.Request): string {
  const host = req.get('host');
  if (host) {
    const proto = req.get('x-forwarded-proto') || req.protocol || 'https';
    return `${proto}://${host}`;
  }
  return process.env.APP_URL || TARGET_DOMAIN;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '256kb' }));

  // Validated Contact Form Endpoint
  app.post('/api/contact', (req, res) => {
    const { name, email, subject, details } = req.body || {};

    if (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 120) {
      res.status(400).json({ ok: false, error: 'Invalid name' });
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (typeof email !== 'string' || !emailRegex.test(email.trim())) {
      res.status(400).json({ ok: false, error: 'Invalid email' });
      return;
    }
    if (typeof subject !== 'string' || subject.trim().length < 3 || subject.trim().length > 200) {
      res.status(400).json({ ok: false, error: 'Invalid subject' });
      return;
    }
    if (typeof details !== 'string' || details.trim().length < 10 || details.trim().length > 4000) {
      res.status(400).json({ ok: false, error: 'Invalid details' });
      return;
    }

    const referenceId = `APX-${Date.now().toString(36).toUpperCase()}`;
    res.status(200).json({
      ok: true,
      referenceId,
      receivedAt: new Date().toISOString(),
    });
  });

  // Dynamic robots.txt
  app.get('/robots.txt', (req, res) => {
    const baseUrl = resolveBaseUrl(req);
    res.type('text/plain').send(`User-agent: *\nAllow: /\n\nSitemap: ${baseUrl}/sitemap.xml\n`);
  });

  // Dynamic sitemap.xml
  app.get('/sitemap.xml', (req, res) => {
    const baseUrl = resolveBaseUrl(req);
    const urls = SITEMAP_PATHS.map(
      (route) =>
        `  <url>\n    <loc>${baseUrl}${route}</loc>\n    <changefreq>weekly</changefreq>\n    <priority>${
          route === '/' ? '1.0' : route === '/apps' ? '0.95' : '0.8'
        }</priority>\n  </url>`
    ).join('\n');

    res
      .type('application/xml')
      .send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, '..', 'dist');
    const fallbackDist = path.resolve(__dirname, 'dist');
    const staticDir = fs.existsSync(distPath) ? distPath : fallbackDist;

    app.use(express.static(staticDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(staticDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`APPLIXO server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
