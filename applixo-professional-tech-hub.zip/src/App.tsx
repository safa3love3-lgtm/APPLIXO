import { useEffect } from 'react';
import { BrowserRouter, Link, Route, Routes, useLocation } from 'react-router-dom';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { AppsStorePage } from './pages/AppsStorePage';
import { AppDetailsPage } from './pages/AppDetailsPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { ServicesPage } from './pages/ServicesPage';
import { TestimonialsPage } from './pages/TestimonialsPage';
import { CustomDevelopmentPage } from './pages/CustomDevelopmentPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage, TermsOfUsePage } from './pages/LegalPages';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname]);
  return null;
}

function NotFoundPage() {
  const { t } = useLanguage();
  return (
    <div className="pt-36 pb-24 min-h-[70vh] flex flex-col items-center justify-center px-4 text-center space-y-5">
      <div className="font-mono-tech text-5xl font-extrabold text-[#00D9FF]">404</div>
      <h1 className="text-2xl sm:text-3xl font-bold text-white">
        {t('الصفحة غير موجودة', 'Page Not Found')}
      </h1>
      <p className="text-sm text-slate-400 max-w-md">
        {t(
          'عذرًا، الصفحة التي تبحث عنها غير متاحة. يمكنك العودة إلى الصفحة الرئيسية أو تصفح متجر التطبيقات.',
          'The page you are looking for is unavailable. Return home or browse our Android apps store.'
        )}
      </p>
      <div className="flex flex-wrap gap-3">
        <Link
          to="/"
          className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#087BFF]"
        >
          {t('الصفحة الرئيسية', 'Go Home')}
        </Link>
        <Link
          to="/apps"
          className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#07152F] border border-white/15"
        >
          {t('متجر التطبيقات', 'Apps Store')}
        </Link>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <ScrollToTop />
        <div className="min-h-screen flex flex-col bg-[#020B1D] text-white">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/apps" element={<AppsStorePage />} />
              <Route path="/apps/:slug" element={<AppDetailsPage />} />
              <Route path="/portfolio" element={<PortfolioPage />} />
              <Route path="/services" element={<ServicesPage />} />
              <Route path="/testimonials" element={<TestimonialsPage />} />
              <Route path="/custom-development" element={<CustomDevelopmentPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms-of-use" element={<TermsOfUsePage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </LanguageProvider>
  );
}
