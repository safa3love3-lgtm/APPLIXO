import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Globe, ArrowUpRight } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';

export function Navbar() {
  const { lang, toggleLang, t } = useLanguage();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { path: '/', labelAr: 'الرئيسية', labelEn: 'Home' },
    { path: '/about', labelAr: 'من نحن', labelEn: 'About' },
    { path: '/apps', labelAr: 'التطبيقات', labelEn: 'Apps' },
    { path: '/portfolio', labelAr: 'أعمالنا', labelEn: 'Portfolio' },
    { path: '/services', labelAr: 'خدماتنا', labelEn: 'Services' },
    { path: '/testimonials', labelAr: 'آراء العملاء', labelEn: 'Testimonials' },
    { path: '/custom-development', labelAr: 'برمجة حسب الطلب', labelEn: 'Custom Dev' },
    { path: '/contact', labelAr: 'تواصل معنا', labelEn: 'Contact' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  return (
    <>
      <header className="fixed top-0 inset-x-0 z-50 h-16 bg-[#020B1D]/85 backdrop-blur-xl border-b border-[#087BFF]/20">
        <div className="max-w-[1400px] mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <Link
            to="/"
            className="flex items-center gap-2.5 shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D9FF] rounded-lg"
          >
            <img
              src={SITE_CONFIG.logoUrl}
              alt="APPLIXO"
              className="w-9 h-9 rounded-full object-cover border border-[#00D9FF]/40 shadow-[0_0_15px_rgba(0,217,255,0.28)]"
            />
            <span className="font-display-en text-lg font-bold tracking-tight text-white whitespace-nowrap">
              APPLI<span className="text-[#00D9FF]">XO</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav
            aria-label={t('القائمة الرئيسية', 'Main Navigation')}
            className="hidden lg:flex items-center gap-4 xl:gap-6"
          >
            {navLinks.map((item) => {
              const active = isActive(item.path);
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`relative py-1 text-[13px] font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                    active
                      ? 'text-[#00D9FF]'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {t(item.labelAr, item.labelEn)}
                  {active && (
                    <span
                      className="absolute bottom-0 inset-x-0 h-[2px] rounded-full bg-gradient-to-r from-[#087BFF] to-[#00D9FF]"
                      aria-hidden="true"
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Actions: Language Toggle + Order CTA + Mobile Drawer Trigger */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={toggleLang}
              aria-label={t('Switch to English', 'التبديل إلى العربية')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-200 bg-[#07152F] border border-[#087BFF]/30 hover:border-[#00D9FF]/60 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-[#00D9FF]" />
              <span>{lang === 'ar' ? 'EN' : 'عربي'}</span>
            </button>

            <Link
              to="/custom-development"
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-[#087BFF] to-[#00A3FF] hover:brightness-110 shadow-[0_0_20px_rgba(8,123,255,0.35)] transition-all whitespace-nowrap shrink-0"
            >
              <span>{t('اطلب تطبيقك', 'Order Your App')}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>

            <button
              type="button"
              onClick={() => setMobileOpen((prev) => !prev)}
              aria-expanded={mobileOpen}
              aria-label={t('فتح القائمة', 'Toggle navigation menu')}
              className="lg:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg bg-[#07152F] border border-[#087BFF]/30 text-white hover:border-[#00D9FF] transition-colors cursor-pointer"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Side Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside
            className={`absolute top-16 bottom-0 ${
              lang === 'ar' ? 'right-0 border-l' : 'left-0 border-r'
            } w-72 max-w-[84vw] bg-[#07152F] border-[#087BFF]/25 p-5 flex flex-col justify-between overflow-y-auto shadow-2xl`}
          >
            <nav className="flex flex-col gap-1.5">
              {navLinks.map((item) => {
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      active
                        ? 'bg-[#087BFF]/20 text-[#00D9FF] border border-[#087BFF]/40'
                        : 'text-slate-200 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {t(item.labelAr, item.labelEn)}
                  </Link>
                );
              })}
            </nav>

            <div className="pt-5 mt-5 border-t border-white/10 space-y-3">
              <Link
                to="/custom-development"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-[#087BFF] to-[#00A3FF]"
              >
                <span>{t('اطلب تطبيقك', 'Order Your App')}</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
