import { Link } from 'react-router-dom';
import { Mail, MessageCircle } from 'lucide-react';
import {
  buildMailtoUrl,
  buildWhatsAppUrl,
  getActiveBaseUrl,
  SITE_CONFIG,
} from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';

export function Footer() {
  const { t } = useLanguage();

  const whatsappGreeting = t(
    'مرحبًا فريق APPLIXO، أرغب في الاستفسار عن تطبيقاتكم وخدماتكم.',
    'Hello APPLIXO team, I would like to inquire about your Android apps and services.'
  );

  return (
    <footer className="border-t border-[#087BFF]/20 bg-[#020B1D] text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Summary */}
          <div className="space-y-4">
            <Link to="/" className="inline-flex items-center gap-3">
              <img
                src={SITE_CONFIG.logoUrl}
                alt="APPLIXO"
                className="w-11 h-11 rounded-full object-cover border border-[#00D9FF]/40"
              />
              <div>
                <div className="font-display-en text-xl font-bold text-white">
                  APPLI<span className="text-[#00D9FF]">XO</span>
                </div>
                <div className="text-xs text-slate-400">
                  {t('تطبيقات ذكية.. إمكانيات بلا حدود', 'Smart Apps. Limitless Possibilities.')}
                </div>
              </div>
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
              {t(
                'شركة متخصصة في تطوير وبيع تطبيقات Android الجاهزة وبرمجة الحلول الرقمية المخصصة للعملاء حول العالم.',
                'Specialized in engineering and selling ready-to-launch Android applications and custom mobile solutions worldwide.'
              )}
            </p>
          </div>

          {/* Explore Links */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t('روابط سريعة', 'Navigation')}
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="hover:text-[#00D9FF] transition-colors">
                  {t('الرئيسية', 'Home')}
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-[#00D9FF] transition-colors">
                  {t('من نحن', 'About Us')}
                </Link>
              </li>
              <li>
                <Link to="/apps" className="hover:text-[#00D9FF] transition-colors">
                  {t('متجر التطبيقات', 'Apps Store')}
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="hover:text-[#00D9FF] transition-colors">
                  {t('أعمالنا', 'Portfolio')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Services & Legal */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t('الخدمات والسياسات', 'Services & Legal')}
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/services" className="hover:text-[#00D9FF] transition-colors">
                  {t('خدماتنا', 'Services')}
                </Link>
              </li>
              <li>
                <Link to="/custom-development" className="hover:text-[#00D9FF] transition-colors">
                  {t('برمجة حسب الطلب', 'Custom Development')}
                </Link>
              </li>
              <li>
                <Link to="/testimonials" className="hover:text-[#00D9FF] transition-colors">
                  {t('آراء العملاء', 'Testimonials')}
                </Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="hover:text-[#00D9FF] transition-colors">
                  {t('سياسة الخصوصية', 'Privacy Policy')}
                </Link>
              </li>
              <li>
                <Link to="/terms-of-use" className="hover:text-[#00D9FF] transition-colors">
                  {t('شروط الاستخدام', 'Terms of Use')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Official Contact */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t('تواصل معنا', 'Direct Contact')}
            </h3>
            <div className="space-y-3 text-sm">
              <a
                href={buildMailtoUrl(t('استفسار من موقع APPLIXO', 'Inquiry from APPLIXO Website'))}
                className="flex items-center gap-2.5 text-slate-300 hover:text-[#00D9FF] transition-colors"
              >
                <Mail className="w-4 h-4 text-[#00D9FF] shrink-0" />
                <span className="font-mono-tech" dir="ltr">
                  {SITE_CONFIG.contact.email}
                </span>
              </a>
              <a
                href={buildWhatsAppUrl(whatsappGreeting)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-slate-300 hover:text-[#16D65A] transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-[#16D65A] shrink-0" />
                <span className="font-mono-tech" dir="ltr">
                  {SITE_CONFIG.contact.whatsappDisplay}
                </span>
              </a>

              {SITE_CONFIG.socialLinks.length > 0 && (
                <div className="pt-2 flex flex-wrap gap-3">
                  {SITE_CONFIG.socialLinks.map((social) => (
                    <a
                      key={social.id}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-slate-400 hover:text-[#00D9FF]"
                    >
                      {t(social.labelAr, social.labelEn)}
                    </a>
                  ))}
                </div>
              )}

              <div className="pt-2 space-y-2">
                <div className="text-xs text-slate-400">
                  {t('رابط الموقع المؤقت المباشر:', 'Live Temporary Website Link:')}
                </div>
                <a
                  href={getActiveBaseUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block font-mono-tech text-xs text-[#00D9FF] hover:underline break-all"
                  dir="ltr"
                >
                  {getActiveBaseUrl()}
                </a>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#07152F] border border-[#087BFF]/40 hover:border-[#00D9FF] transition-colors mt-1"
                >
                  {t('صفحة التواصل الكاملة', 'Open Contact Page')}
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>
            {t(
              '© APPLIXO. جميع الحقوق محفوظة.',
              '© APPLIXO. All rights reserved.'
            )}
          </p>
          <p className="text-slate-500">
            {t('Your Ideas. Our Technology. Endless Possibilities.', 'Your Ideas. Our Technology. Endless Possibilities.')}
          </p>
        </div>
      </div>
    </footer>
  );
}
