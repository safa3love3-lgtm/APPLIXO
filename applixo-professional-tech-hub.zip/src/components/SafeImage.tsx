import React, { useState } from 'react';
import { Smartphone } from 'lucide-react';

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
  fallbackTitle?: string;
}

export function SafeImage({
  src,
  alt,
  className = '',
  loading = 'lazy',
  fallbackTitle,
}: SafeImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#07152F] via-[#0B1E42] to-[#020B1D] text-slate-300 p-4 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Smartphone className="w-8 h-8 text-[#00D9FF] mb-2 opacity-80" />
        <span className="text-xs font-medium text-slate-300 line-clamp-2">
          {fallbackTitle || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading={loading}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
