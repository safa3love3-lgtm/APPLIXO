import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getActiveBaseUrl, SITE_CONFIG } from '../config/siteConfig';

interface SeoHeadProps {
  title: string;
  description: string;
  image?: string;
}

export function SeoHead({ title, description, image }: SeoHeadProps) {
  const location = useLocation();

  useEffect(() => {
    const fullTitle = title.includes(SITE_CONFIG.brandName)
      ? title
      : `${title} | ${SITE_CONFIG.brandName}`;
    document.title = fullTitle;

    const setMeta = (selector: string, attr: 'name' | 'property', key: string, content: string) => {
      let el = document.querySelector<HTMLMetaElement>(selector);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    setMeta('meta[name="description"]', 'name', 'description', description);
    setMeta('meta[property="og:title"]', 'property', 'og:title', fullTitle);
    setMeta('meta[property="og:description"]', 'property', 'og:description', description);
    setMeta('meta[name="twitter:title"]', 'name', 'twitter:title', fullTitle);
    setMeta('meta[name="twitter:description"]', 'name', 'twitter:description', description);

    const baseUrl = getActiveBaseUrl();
    const canonicalUrl = `${baseUrl}${location.pathname}`;
    setMeta('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);

    if (image) {
      const absImage = image.startsWith('http') ? image : `${baseUrl}${image}`;
      setMeta('meta[property="og:image"]', 'property', 'og:image', absImage);
    }

    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', canonicalUrl);
  }, [title, description, image, location.pathname]);

  return null;
}
