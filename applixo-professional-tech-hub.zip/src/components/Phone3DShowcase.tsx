import React, { useState } from 'react';
import { SafeImage } from './SafeImage';

interface Phone3DShowcaseProps {
  image: string;
  alt: string;
  accentHex?: string;
  title?: string;
  subtitle?: string;
  badgeText?: string;
  children?: React.ReactNode;
  className?: string;
}

export function Phone3DShowcase({
  image,
  alt,
  accentHex = '#087BFF',
  title,
  subtitle,
  badgeText,
  children,
  className = '',
}: Phone3DShowcaseProps) {
  const [tilt, setTilt] = useState({ rotateX: 0, rotateY: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({
      rotateX: Number((-y * 10).toFixed(2)),
      rotateY: Number((x * 12).toFixed(2)),
    });
  };

  const handleMouseLeave = () => {
    setTilt({ rotateX: 0, rotateY: 0 });
  };

  return (
    <div
      className={`perspective-1200 relative group ${className}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {/* Subtle ambient glow behind 3D Android frame */}
      <div
        className="absolute -inset-3 rounded-[2rem] opacity-35 blur-2xl transition-opacity duration-300 group-hover:opacity-60 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 45%, ${accentHex}55, transparent 70%)`,
        }}
        aria-hidden="true"
      />

      <div
        className="relative rounded-[1.75rem] bg-[#040E22] p-2.5 border border-white/15 shadow-[0_28px_60px_-15px_rgba(0,0,0,0.85)] transition-transform duration-200 ease-out preserve-3d"
        style={{
          transform: `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg)`,
        }}
      >
        {/* Modern Android Bezel Top Speaker / Camera Notch */}
        <div className="flex items-center justify-between px-3 py-1.5 mb-1">
          <div className="flex items-center gap-1.5">
            <span
              className="inline-block w-2 h-2 rounded-full"
              style={{ backgroundColor: '#16D65A' }}
              aria-hidden="true"
            />
            <span className="text-[11px] font-mono-tech text-slate-300 tracking-wide">
              Android
            </span>
          </div>
          <div className="w-12 h-1.5 rounded-full bg-white/10" aria-hidden="true" />
          {badgeText ? (
            <span className="text-[11px] font-mono-tech text-[#00D9FF]">
              {badgeText}
            </span>
          ) : (
            <span className="w-2.5 h-2.5 rounded-full bg-[#07152F] border border-white/20" aria-hidden="true" />
          )}
        </div>

        {/* Screen Container */}
        <div className="relative overflow-hidden rounded-[1.25rem] bg-[#020B1D] border border-white/10">
          <SafeImage
            src={image}
            alt={alt}
            loading="eager"
            className="w-full aspect-[4/3] object-cover transition-transform duration-500 group-hover:scale-[1.03]"
          />

          {(title || subtitle) && (
            <div className="bg-gradient-to-t from-[#020B1D] via-[#020B1D]/85 to-transparent p-4 pt-10 -mt-12 relative z-10">
              {title && (
                <h4 className="text-sm font-semibold text-white truncate">
                  {title}
                </h4>
              )}
              {subtitle && (
                <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                  {subtitle}
                </p>
              )}
            </div>
          )}

          {children}
        </div>

        {/* Android Gesture Navigation Pill */}
        <div className="flex justify-center pt-2 pb-0.5" aria-hidden="true">
          <div className="w-20 h-1 rounded-full bg-white/20" />
        </div>
      </div>
    </div>
  );
}
