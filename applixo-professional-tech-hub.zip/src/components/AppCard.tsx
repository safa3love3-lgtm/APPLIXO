import { Link } from 'react-router-dom';
import { ArrowUpRight, MessageCircle, Check } from 'lucide-react';
import type { AndroidAppItem } from '../data/appsData';
import { buildWhatsAppUrl } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SafeImage } from './SafeImage';

interface AppCardProps {
  app: AndroidAppItem;
}

export function AppCard({ app }: AppCardProps) {
  const { t } = useLanguage();

  const name = t(app.nameAr, app.nameEn);
  const category = t(app.categoryAr, app.categoryEn);
  const shortDesc = t(app.shortDescAr, app.shortDescEn);
  const statusText = t('تم البيع', 'Sold');

  const topFeatures = t(app.featuresAr, app.featuresEn).slice(0, 3);

  const waMessage = t(
    `مرحبًا فريق APPLIXO، اطلعت على تطبيق "${app.nameAr}" وأرغب في الاستفسار عن تنفيذ نسخة مخصصة مشابهة.`,
    `Hello APPLIXO team, I viewed "${app.nameEn}" and would like to inquire about building a similar custom app.`
  );

  return (
    <article className="group flex flex-col rounded-2xl bg-[#07152F]/75 border border-[#087BFF]/20 hover:border-[#00D9FF]/50 transition-all duration-200 overflow-hidden shadow-[0_14px_34px_-16px_rgba(0,0,0,0.65)] hover:-translate-y-0.5">
      {/* Independent App Image Inside Clean Dark Frame */}
      <Link to={`/apps/${app.slug}`} className="relative block overflow-hidden bg-[#020B1D]">
        <SafeImage
          src={app.image}
          alt={name}
          className="w-full aspect-[4/3] object-cover transition-transform duration-500 group-hover:scale-[1.04]"
          fallbackTitle={name}
        />
        <div
          className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#07152F] to-transparent pointer-events-none"
          aria-hidden="true"
        />
      </Link>

      {/* Card Body */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between gap-5">
        <div className="space-y-3">
          {/* Unboxed Clean Metadata Line */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-[#00D9FF] font-medium">{category}</span>
            <span className="font-semibold text-amber-300">
              {statusText}
            </span>
          </div>

          {/* App Title (No Price Displayed) */}
          <div>
            <Link
              to={`/apps/${app.slug}`}
              className="text-lg font-bold text-white hover:text-[#00D9FF] transition-colors leading-snug block"
            >
              {name}
            </Link>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed line-clamp-2">
            {shortDesc}
          </p>

          {/* Key Features */}
          <ul className="space-y-1.5 pt-2 border-t border-white/10">
            {topFeatures.map((feat, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                <Check className="w-3.5 h-3.5 text-[#16D65A] shrink-0 mt-0.5" />
                <span className="line-clamp-1">{feat}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2.5 pt-2">
          <Link
            to={`/apps/${app.slug}`}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#020B1D] border border-[#087BFF]/40 hover:border-[#00D9FF] transition-colors whitespace-nowrap"
          >
            <span>{t('عرض التفاصيل', 'View Details')}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>

          <a
            href={buildWhatsAppUrl(waMessage)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-semibold text-[#020B1D] bg-[#16D65A] hover:brightness-110 transition-all whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>{t('اطلب نسخة مماثلة', 'Request Similar')}</span>
          </a>
        </div>
      </div>
    </article>
  );
}
