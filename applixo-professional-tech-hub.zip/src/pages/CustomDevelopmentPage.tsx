import { useState } from 'react';
import { MessageCircle, CheckCircle2, Smartphone } from 'lucide-react';
import { buildWhatsAppUrl } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';

export function CustomDevelopmentPage() {
  const { t } = useLanguage();

  const [ideaTitle, setIdeaTitle] = useState('');
  const [appCategory, setAppCategory] = useState('business');
  const [briefDetails, setBriefDetails] = useState('');

  const steps = [
    {
      num: '01',
      titleAr: 'إرسال فكرة المشروع',
      titleEn: 'Submit Your Project Idea',
      descAr:
        'تشاركنا فكرة التطبيق، الفئة المستهدفة، وأهم الأهداف التي تريد تحقيقها عبر WhatsApp أو نموذج الطلب.',
      descEn:
        'Share your app concept, target audience, and primary business objectives via WhatsApp or our inquiry brief.',
    },
    {
      num: '02',
      titleAr: 'دراسة الفكرة وتحديد المتطلبات',
      titleEn: 'Discovery & Requirements Mapping',
      descAr:
        'يدرس فريقنا المتطلبات التقنية، عدد الشاشات، التكاملات المطلوبة، ويقترح أفضل بنية لتطبيق Android.',
      descEn:
        'Our engineers analyze technical requirements, screen flows, APIs, and define the optimal Android architecture.',
    },
    {
      num: '03',
      titleAr: 'الاتفاق على السعر والمدة',
      titleEn: 'Transparent Scope, Quote & Timeline',
      descAr:
        'نقدم عرضًا واضحًا يشمل التكلفة الإجمالية، مراحل التسليم، والجدول الزمني الدقيق قبل بدء التنفيذ.',
      descEn:
        'We present a clear proposal detailing total cost, milestone deliverables, and exact schedule prior to kickoff.',
    },
    {
      num: '04',
      titleAr: 'تصميم واجهات التطبيق',
      titleEn: 'UI/UX Interface Design',
      descAr:
        'نصمم واجهات عصرية متوافقة مع هوية علامتك التجارية وتدعم اللغة العربية والإنجليزية بسلاسة تامة.',
      descEn:
        'We craft sleek, brand-aligned UI/UX prototypes with native Arabic RTL and English LTR parity.',
    },
    {
      num: '05',
      titleAr: 'البرمجة والتطوير',
      titleEn: 'Android Engineering & Integration',
      descAr:
        'كتابة الشيفرة البرمجية النظيفة، بناء الميزات الأساسية، وربط الخوادم وواجهات البرمجة بأعلى معايير الأمان.',
      descEn:
        'Clean Kotlin/Compose engineering, core feature implementation, and secure backend API integration.',
    },
    {
      num: '06',
      titleAr: 'الاختبار والتسليم',
      titleEn: 'Quality Assurance & Handover',
      descAr:
        'اختبار التطبيق على أحجام شاشات وإصدارات Android متعددة ثم تسليم الحزمة النهائية الجاهزة للنشر.',
      descEn:
        'Thorough testing across multiple Android versions and screen sizes, followed by release-ready handover.',
    },
  ];

  const categoryLabels: Record<string, { ar: string; en: string }> = {
    business: { ar: 'تطبيق أعمال / متجر / خدمات', en: 'Business / Commerce / Services' },
    ai: { ar: 'تطبيق ذكاء اصطناعي', en: 'AI-Powered Application' },
    media: { ar: 'فيديو / صوتيات / محتوى', en: 'Video / Audio / Media' },
    chat: { ar: 'تواصل ومجتمعات', en: 'Chat & Community' },
    productivity: { ar: 'أدوات وإنتاجية / تعليم', en: 'Productivity / Tools / Education' },
  };

  const composedWaMessage = t(
    `مرحبًا فريق APPLIXO، أرغب في طلب عرض سعر لبرمجة تطبيق Android حسب الطلب.\n` +
      `اسم/فكرة المشروع: ${ideaTitle || 'غير محدد بعد'}\n` +
      `التصنيف: ${categoryLabels[appCategory]?.ar}\n` +
      `التفاصيل: ${briefDetails || 'أرغب في مناقشة التفاصيل مع الفريق.'}`,
    `Hello APPLIXO team, I would like a quote for custom Android app development.\n` +
      `Project Idea: ${ideaTitle || 'Not specified yet'}\n` +
      `Category: ${categoryLabels[appCategory]?.en}\n` +
      `Details: ${briefDetails || 'I would like to discuss the project scope.'}`
  );

  return (
    <>
      <SeoHead
        title={t('برمجة التطبيقات حسب الطلب – اطلب تطبيقك', 'Custom Android App Development')}
        description={t(
          'لديك فكرة تطبيق؟ نحن نحولها إلى واقع. تعرف على خطوات تطوير تطبيقات Android حسب الطلب في APPLIXO واطلب عرض سعر الآن.',
          'Have an app idea? We turn it into reality. Review our 6-step custom Android engineering process and request a quote on WhatsApp.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Heading */}
          <div className="max-w-3xl space-y-4 mb-14">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-[#16D65A]">
              <Smartphone className="w-4 h-4" />
              <span>{t('برمجة تطبيقات Android حسب الطلب', 'Bespoke Android Engineering')}</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t(
                'لديك فكرة تطبيق؟ نحن نحولها إلى واقع.',
                'Have an App Idea? We Turn It Into Reality.'
              )}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'سواء كنت تطلق شركة ناشئة أو تطور أداة رقمية لمؤسستك، نتولى تصميم وبرمجة تطبيق Android متكامل يعبر عن رؤيتك بأعلى جودة.',
                'Whether launching a new venture or scaling an enterprise tool, we handle complete Android UI/UX design, native coding, and release readiness.'
              )}
            </p>
          </div>

          {/* 6 Steps Workflow */}
          <section className="mb-16">
            <h2 className="text-2xl font-bold text-white mb-8">
              {t('خطوات العمل في APPLIXO', 'How We Build Your App')}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {steps.map((step) => (
                <div
                  key={step.num}
                  className="glass-surface rounded-2xl p-6 space-y-3 hover:border-[#00D9FF]/45 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono-tech text-lg font-extrabold text-[#00D9FF]">
                      {step.num}
                    </span>
                    <CheckCircle2 className="w-4 h-4 text-[#16D65A]" />
                  </div>
                  <h3 className="text-lg font-bold text-white">
                    {t(step.titleAr, step.titleEn)}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {t(step.descAr, step.descEn)}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* Interactive Quote Request Builder -> WhatsApp */}
          <section className="glass-surface-elevated rounded-3xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <h2 className="text-2xl sm:text-3xl font-bold text-white">
                {t('اطلب عرض سعر فوري عبر WhatsApp', 'Request a Custom Quote on WhatsApp')}
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {t(
                  'أدخل نبذة سريعة عن فكرتك ليتم تجهيز رسالة منظمة ومباشرة لفريقنا الهندسي عبر WhatsApp، أو تواصل فورًا دون ملء الحقول.',
                  'Enter a quick summary of your idea to generate a structured project brief for our engineering team on WhatsApp.'
                )}
              </p>
              <a
                href={buildWhatsAppUrl(composedWaMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-xl text-sm font-bold text-[#020B1D] bg-[#16D65A] hover:brightness-110 shadow-[0_0_24px_rgba(22,214,90,0.3)] transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t('فتح WhatsApp وطلب عرض سعر', 'Open WhatsApp & Request Quote')}</span>
              </a>
            </div>

            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    {t('اسم المشروع أو الفكرة', 'Project / App Name')}
                  </label>
                  <input
                    type="text"
                    value={ideaTitle}
                    onChange={(e) => setIdeaTitle(e.target.value)}
                    placeholder={t('مثال: تطبيق توصيل ذكي', 'e.g., Smart Delivery App')}
                    className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-2.5 text-sm text-white placeholder:text-slate-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    {t('نوع التطبيق', 'Application Category')}
                  </label>
                  <select
                    value={appCategory}
                    onChange={(e) => setAppCategory(e.target.value)}
                    className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-2.5 text-sm text-white"
                  >
                    {Object.entries(categoryLabels).map(([key, val]) => (
                      <option key={key} value={key}>
                        {t(val.ar, val.en)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {t('ملخص المتطلبات والمميزات', 'Key Features & Requirements')}
                </label>
                <textarea
                  rows={3}
                  value={briefDetails}
                  onChange={(e) => setBriefDetails(e.target.value)}
                  placeholder={t(
                    'اذكر بإيجاز الشاشات الأساسية أو الميزات التي تحتاجها في التطبيق...',
                    'Briefly describe the main screens or capabilities you need...'
                  )}
                  className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-2.5 text-sm text-white placeholder:text-slate-500"
                />
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
