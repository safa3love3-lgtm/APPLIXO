import { useMemo, useState } from 'react';
import { Search, Smartphone } from 'lucide-react';
import {
  APP_CATEGORIES,
  APPS_DATA,
  type AppCategoryId,
} from '../data/appsData';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';
import { AppCard } from '../components/AppCard';

export function AppsStorePage() {
  const { t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<AppCategoryId>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredApps = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return APPS_DATA.filter((app) => {
      const matchesCat = selectedCategory === 'all' || app.categoryId === selectedCategory;
      if (!matchesCat) return false;
      if (!q) return true;

      return (
        app.nameAr.toLowerCase().includes(q) ||
        app.nameEn.toLowerCase().includes(q) ||
        app.shortDescAr.toLowerCase().includes(q) ||
        app.shortDescEn.toLowerCase().includes(q) ||
        app.categoryAr.toLowerCase().includes(q) ||
        app.categoryEn.toLowerCase().includes(q)
      );
    });
  }, [selectedCategory, searchQuery]);

  return (
    <>
      <SeoHead
        title={t('التطبيقات – تطبيقات Android المطورة والمباعة', 'Apps – Delivered & Sold Android Applications')}
        description={t(
          'استعرض تطبيقات Android التي طورتها شركة APPLIXO وتم بيعها بنجاح، مع إمكانية طلب نسخة مخصصة مماثلة لمشروعك.',
          'Explore Android applications engineered and sold by APPLIXO across Business, AI, Video, Audio, Chat, and Productivity.'
        )}
      />

      <div className="pt-28 pb-20 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="max-w-3xl space-y-4 mb-10">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-[#16D65A]">
              <Smartphone className="w-4 h-4" />
              <span>{t('منصة تطبيقات Android', 'Android App Catalog')}</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t('تطبيقات APPLIXO', 'APPLIXO Android Apps')}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'مجموعة من تطبيقات Android التي تم تطويرها وبيعها بالكامل بهويات مختلفة. يمكنك استعراض تفاصيل كل تطبيق أو طلب تطوير نسخة خاصة بمشروعك عبر WhatsApp.',
                'A showcase of Android applications engineered and sold across diverse categories. Explore each app in detail or request a custom version tailored to your brand.'
              )}
            </p>
          </div>

          {/* Search & Category Filter Toolbar */}
          <div className="glass-surface rounded-2xl p-4 sm:p-5 mb-10 space-y-4">
            <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
              {/* Search Box */}
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t(
                    'ابحث باسم التطبيق أو التصنيف أو الميزة...',
                    'Search apps by name, category, or feature...'
                  )}
                  className="w-full bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none rounded-xl py-2.5 ps-10 pe-4 text-sm text-white placeholder:text-slate-500"
                />
              </div>

              <div className="text-xs font-medium text-amber-300">
                {t('الحالة العامة: جميع النماذج المعروضة تم بيعها · متاح طلب نسخ مخصصة', 'Status: All listed apps are sold · Custom builds available on request')}
              </div>
            </div>

            {/* Category Filter Buttons */}
            <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-white/10">
              {APP_CATEGORIES.map((cat) => {
                const active = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                      active
                        ? 'bg-gradient-to-r from-[#087BFF] to-[#00A3FF] text-white shadow-[0_0_16px_rgba(8,123,255,0.35)]'
                        : 'bg-[#020B1D]/80 text-slate-300 border border-white/10 hover:border-[#00D9FF]/40 hover:text-white'
                    }`}
                  >
                    {t(cat.labelAr, cat.labelEn)}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-between mb-6 text-xs text-slate-400">
            <span>
              {t(
                `عرض ${filteredApps.length} تطبيق من أصل ${APPS_DATA.length}`,
                `Showing ${filteredApps.length} of ${APPS_DATA.length} apps`
              )}
            </span>
          </div>

          {/* Apps Grid */}
          {filteredApps.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredApps.map((app) => (
                <AppCard key={app.slug} app={app} />
              ))}
            </div>
          ) : (
            <div className="glass-surface rounded-2xl p-12 text-center space-y-4">
              <p className="text-lg font-semibold text-white">
                {t('لم يتم العثور على تطبيقات مطابقة', 'No matching apps found')}
              </p>
              <p className="text-sm text-slate-400">
                {t(
                  'جرّب تغيير كلمات البحث أو اختيار تصنيف آخر، أو تواصل معنا لبرمجة تطبيقك المخصص.',
                  'Try adjusting your search or category filter, or contact us to build a custom app.'
                )}
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="px-5 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#087BFF] hover:brightness-110 cursor-pointer"
              >
                {t('إعادة ضبط الفلاتر', 'Reset Filters')}
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
