import React, { useState } from 'react';
import {
  Mail,
  MessageCircle,
  Send,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ExternalLink,
} from 'lucide-react';
import {
  buildMailtoUrl,
  buildWhatsAppUrl,
  getActiveBaseUrl,
  SITE_CONFIG,
} from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';

interface FormState {
  name: string;
  email: string;
  subject: string;
  details: string;
}

export function ContactPage() {
  const { lang, t } = useLanguage();

  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    subject: '',
    details: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [emailCopied, setEmailCopied] = useState(false);

  const autoWhatsAppText = t(
    'مرحبًا فريق APPLIXO، أتواصل معكم عبر الموقع الرسمي للاستفسار عن تطبيقاتكم وخدمات التطوير.',
    'Hello APPLIXO team, I am contacting you from the official website regarding your Android apps and services.'
  );

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(SITE_CONFIG.contact.email);
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 2200);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const name = form.name.trim();
    const email = form.email.trim();
    const subject = form.subject.trim();
    const details = form.details.trim();

    if (name.length < 2) {
      setStatusMessage({
        type: 'error',
        text: t('يرجى إدخال الاسم بشكل صحيح.', 'Please enter your full name.'),
      });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setStatusMessage({
        type: 'error',
        text: t(
          'يرجى إدخال بريد إلكتروني صحيح.',
          'Please enter a valid email address.'
        ),
      });
      return;
    }

    if (subject.length < 3 || details.length < 10) {
      setStatusMessage({
        type: 'error',
        text: t(
          'يرجى كتابة موضوع الرسالة وتفاصيل الطلب (10 أحرف على الأقل).',
          'Please provide a subject and at least 10 characters of request details.'
        ),
      });
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, details, lang }),
      });

      const contentType = response.headers.get('content-type') || '';

      if (contentType.includes('application/json')) {
        const data = await response.json().catch(() => null);
        if (!response.ok || !data?.ok) {
          throw new Error(data?.error || 'Request failed');
        }
        setStatusMessage({
          type: 'success',
          text: t(
            `تم استلام رسالتك بنجاح (رقم المرجع: ${data.referenceId}). يمكنك أيضًا مراسلتنا مباشرة عبر WhatsApp للرد الفوري.`,
            `Your message was received successfully (Reference: ${data.referenceId}). You may also message us on WhatsApp for an immediate reply.`
          ),
        });
        setForm({ name: '', email: '', subject: '', details: '' });
      } else {
        // Static hosting (e.g., Firebase Hosting) fallback: launch formatted email client + confirm
        const mailUrl = buildMailtoUrl(
          subject,
          `${t('الاسم:', 'Name:')} ${name}\n${t('البريد الإلكتروني:', 'Email:')} ${email}\n\n${details}`
        );
        window.location.href = mailUrl;
        setStatusMessage({
          type: 'success',
          text: t(
            'تم التحقق من بياناتك وتجهيز الرسالة في تطبيق البريد الإلكتروني للإرسال إلى info@applixo.com. يمكنك أيضًا مراسلتنا مباشرة عبر WhatsApp.',
            'Your inquiry is validated and ready in your email client for info@applixo.com. You can also reach us instantly via WhatsApp.'
          ),
        });
        setForm({ name: '', email: '', subject: '', details: '' });
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: t(
          'تعذر إرسال النموذج حاليًا. يرجى المحاولة مرة أخرى أو استخدام البريد المباشر / WhatsApp.',
          'Unable to submit the form right now. Please try again or reach us directly via Email or WhatsApp.'
        ),
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <SeoHead
        title={t('تواصل معنا – APPLIXO', 'Contact Us – APPLIXO')}
        description={t(
          'تواصل مع شركة APPLIXO عبر البريد الإلكتروني الرسمي info@applixo.com أو مباشرة عبر WhatsApp أو نموذج التواصل.',
          'Contact APPLIXO via official email info@applixo.com, direct WhatsApp chat, or our validated contact form.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4 mb-12">
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t('تواصل مع فريق APPLIXO', 'Contact APPLIXO')}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'نستقبل طلبات شراء التطبيقات الجاهزة وبرمجة التطبيقات حسب الطلب من جميع أنحاء العالم عبر قنواتنا الرسمية أدناه.',
                'We welcome ready-made app purchases and custom Android inquiries worldwide through our official channels below.'
              )}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Official Direct Channels */}
            <div className="lg:col-span-5 space-y-6">
              {/* WhatsApp Card */}
              <div className="glass-surface-elevated rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-[#16D65A]/15 border border-[#16D65A]/40 flex items-center justify-center text-[#16D65A]">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">
                      {t('تواصل مباشر عبر WhatsApp', 'Direct WhatsApp Chat')}
                    </h2>
                    <div className="font-mono-tech text-xs text-slate-300 mt-0.5" dir="ltr">
                      {SITE_CONFIG.contact.whatsappDisplay}
                    </div>
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {t(
                    'اضغط لفتح محادثة مباشرة معنا برسالة ترحيب تلقائية بلغتك لطلب عرض سعر أو شراء تطبيق.',
                    'Tap below to open a direct chat with an automatic pre-filled greeting for fast inquiries.'
                  )}
                </p>
                <a
                  href={buildWhatsAppUrl(autoWhatsAppText)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-bold text-[#020B1D] bg-[#16D65A] hover:brightness-110 transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t('فتح محادثة WhatsApp', 'Open WhatsApp Chat')}</span>
                </a>
              </div>

              {/* Official Email Card */}
              <div className="glass-surface rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-[#087BFF]/15 border border-[#087BFF]/40 flex items-center justify-center text-[#00D9FF]">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">
                      {t('البريد الإلكتروني الرسمي', 'Official Email')}
                    </h2>
                    <div className="font-mono-tech text-xs text-[#00D9FF] mt-0.5" dir="ltr">
                      {SITE_CONFIG.contact.email}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2.5">
                  <a
                    href={buildMailtoUrl(
                      t('استفسار عبر موقع APPLIXO', 'Inquiry via APPLIXO Website')
                    )}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-[#087BFF] hover:brightness-110 transition-all whitespace-nowrap"
                  >
                    <Mail className="w-4 h-4" />
                    <span>{t('إرسال بريد إلكتروني', 'Send Email')}</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyEmail}
                    className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-[#020B1D] border border-white/15 hover:border-[#00D9FF] transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {emailCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#16D65A]" />
                        <span>{t('تم النسخ', 'Copied')}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>{t('نسخ البريد', 'Copy Email')}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Official Live Temporary Website Link */}
              <div className="glass-surface rounded-2xl p-6 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h2 className="text-base font-bold text-white">
                    {t('رابط الموقع المباشر (مؤقت)', 'Live Temporary Website Link')}
                  </h2>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t(
                    'اضغط على الرابط التالي لفتح الموقع مباشرة، وسيتم استبداله تلقائيًا بالنطاق الدائم عند ربطه.',
                    'Click the link below to open the live website directly. It updates seamlessly once your custom domain is connected.'
                  )}
                </p>
                <a
                  href={getActiveBaseUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  dir="ltr"
                  className="inline-flex items-center gap-2 font-mono-tech text-xs text-[#00D9FF] hover:underline break-all"
                >
                  <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  <span>{getActiveBaseUrl()}</span>
                </a>
              </div>

              {/* Future Social Links slot (only renders when official social accounts are configured) */}
              {SITE_CONFIG.socialLinks.length > 0 && (
                <div className="glass-surface rounded-2xl p-6 space-y-3">
                  <h2 className="text-sm font-bold text-white">
                    {t('حسابات التواصل الاجتماعي', 'Social Channels')}
                  </h2>
                  <div className="flex flex-wrap gap-2.5">
                    {SITE_CONFIG.socialLinks.map((social) => (
                      <a
                        key={social.id}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-2 rounded-lg bg-[#020B1D] border border-white/15 text-xs text-slate-200 hover:border-[#00D9FF]"
                      >
                        {t(social.labelAr, social.labelEn)}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Validated Contact Form */}
            <div className="lg:col-span-7">
              <form
                onSubmit={handleSubmit}
                noValidate
                className="glass-surface-elevated rounded-2xl p-6 sm:p-8 space-y-5"
              >
                <div className="space-y-1">
                  <h2 className="text-xl font-bold text-white">
                    {t('نموذج التواصل والطلبات', 'Send Us a Request')}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400">
                    {t(
                      'لا يلزم إنشاء حساب لإرسال طلبك أو التواصل معنا.',
                      'No account or registration required to submit an inquiry.'
                    )}
                  </p>
                </div>

                {statusMessage && (
                  <div
                    role="status"
                    className={`rounded-xl p-4 flex items-start gap-3 text-sm border ${
                      statusMessage.type === 'success'
                        ? 'bg-[#16D65A]/10 border-[#16D65A]/40 text-emerald-200'
                        : 'bg-red-500/10 border-red-400/40 text-red-200'
                    }`}
                  >
                    {statusMessage.type === 'success' ? (
                      <CheckCircle2 className="w-5 h-5 text-[#16D65A] shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    )}
                    <span>{statusMessage.text}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="contact-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                      {t('الاسم الكامل *', 'Full Name *')}
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                      placeholder={t('أدخل اسمك', 'Enter your name')}
                      className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-3 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-email" className="block text-xs font-medium text-slate-300 mb-1.5">
                      {t('البريد الإلكتروني *', 'Email Address *')}
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      required
                      dir="ltr"
                      value={form.email}
                      onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                      placeholder="name@company.com"
                      className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-3 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="contact-subject" className="block text-xs font-medium text-slate-300 mb-1.5">
                    {t('موضوع الرسالة *', 'Subject *')}
                  </label>
                  <input
                    id="contact-subject"
                    type="text"
                    required
                    value={form.subject}
                    onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                    placeholder={t(
                      'مثال: شراء تطبيق BizPulse أو طلب برمجة تطبيق',
                      'e.g., Licensing BizPulse ERP or Custom Android App'
                    )}
                    className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-3 text-sm text-white placeholder:text-slate-500"
                  />
                </div>

                <div>
                  <label htmlFor="contact-details" className="block text-xs font-medium text-slate-300 mb-1.5">
                    {t('تفاصيل الطلب *', 'Request Details *')}
                  </label>
                  <textarea
                    id="contact-details"
                    rows={5}
                    required
                    value={form.details}
                    onChange={(e) => setForm((f) => ({ ...f, details: e.target.value }))}
                    placeholder={t(
                      'اكتب تفاصيل فكرتك أو التطبيق الذي تود الاستفسار عنه...',
                      'Share the details of your inquiry, project goals, or preferred Android app...'
                    )}
                    className="w-full rounded-xl bg-[#020B1D] border border-[#087BFF]/30 focus:border-[#00D9FF] focus:outline-none px-4 py-3 text-sm text-white placeholder:text-slate-500"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-[#087BFF] to-[#00A3FF] hover:brightness-110 disabled:opacity-60 shadow-[0_0_24px_rgba(8,123,255,0.35)] transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>
                      {submitting
                        ? t('جاري الإرسال...', 'Sending...')
                        : t('إرسال الرسالة', 'Submit Inquiry')}
                    </span>
                  </button>

                  <a
                    href={buildMailtoUrl(
                      form.subject || t('طلب من موقع APPLIXO', 'APPLIXO Inquiry'),
                      form.details
                    )}
                    className="text-xs font-semibold text-[#00D9FF] hover:text-white transition-colors"
                  >
                    {t('أو افتح تطبيق البريد مباشرة', 'Or open your email client directly')}
                  </a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
