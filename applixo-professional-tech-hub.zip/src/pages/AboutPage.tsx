import { Link } from 'react-router-dom';
import { Target, Compass, Award, ArrowUpRight } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';

export function AboutPage() {
  const { t } = useLanguage();

  const values = [
    {
      titleAr: 'الابتكار',
      titleEn: 'Innovation',
      descAr: 'نبحث باستمرار عن أفكار وتقنيات حديثة تجعل تطبيقات Android أكثر ذكاءً وفائدة.',
      descEn: 'Continuously adopting modern mobile architectures and AI capabilities that deliver practical utility.',
    },
    {
      titleAr: 'الجودة',
      titleEn: 'Quality',
      descAr: 'نهتم بأدق تفاصيل الكود والأداء وسرعة الاستجابة على مختلف أجهزة Android.',
      descEn: 'Strict attention to code hygiene, smooth frame rates, and stability across diverse Android hardware.',
    },
    {
      titleAr: 'الاحترافية',
      titleEn: 'Professionalism',
      descAr: 'نلتزم بوضوح المواعيد، توثيق التسليمات، والتواصل المنتظم في جميع مراحل المشروع.',
      descEn: 'Clear milestone schedules, thorough documentation, and disciplined execution from kickoff to handover.',
    },
    {
      titleAr: 'الشفافية',
      titleEn: 'Transparency',
      descAr: 'نوضح التكاليف والمتطلبات والحدود التقنية بصدق ووضوح منذ اليوم الأول.',
      descEn: 'Honest communication around scope, timelines, pricing, and capabilities from day one.',
    },
    {
      titleAr: 'الاهتمام بالعملاء',
      titleEn: 'Client Focus',
      descAr: 'نجاح مشروع العميل هو مقياس نجاحنا، لذا نصغي لاحتياجاته ونقدم حلولًا عملية تدعمه.',
      descEn: 'Every product decision centers on helping our clients launch sustainable, user-friendly software.',
    },
  ];

  return (
    <>
      <SeoHead
        title={t('من نحن – قصة ورؤية APPLIXO', 'About Us – APPLIXO Story, Vision & Values')}
        description={t(
          'تعرف على قصة شركة APPLIXO المتخصصة في تطوير وبيع تطبيقات Android، ورؤيتها ورسالتها وقيمها الخمس.',
          'Learn about APPLIXO, our vision, mission, and core values in Android application engineering and digital solutions.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {/* Header & Story */}
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-5">
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
                {t('من نحن؟ قصة APPLIXO', 'About APPLIXO')}
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                {t(
                  'APPLIXO شركة متخصصة في تطوير وبيع تطبيقات Android، نعمل على تقديم حلول رقمية مبتكرة تساعد الأفراد والشركات على تحقيق أفكارهم وتحويلها إلى تطبيقات عملية.',
                  'APPLIXO is a specialized technology company focused on developing and selling Android applications, helping individuals and enterprises turn ideas into dependable mobile products.'
                )}
              </p>
              <p className="text-base text-slate-300 leading-relaxed">
                {t(
                  'نؤمن أن التكنولوجيا ليست مجرد أدوات، بل وسيلة لصناعة تجارب أفضل وتوفير حلول ذكية تلبي احتياجات المستخدمين في العالم العربي والعالم أجمع.',
                  'We believe technology is not merely a collection of tools, but a craft for shaping better everyday experiences and intelligent software solutions worldwide.'
                )}
              </p>
            </div>

            <div className="lg:col-span-5 flex justify-center">
              <div className="glass-surface-elevated rounded-3xl p-8 text-center space-y-4 max-w-sm w-full">
                <img
                  src={SITE_CONFIG.logoUrl}
                  alt="APPLIXO"
                  className="w-32 h-32 mx-auto rounded-full object-cover border-2 border-[#00D9FF]/50 shadow-[0_0_36px_rgba(0,217,255,0.3)]"
                />
                <div className="font-display-en text-2xl font-extrabold text-white">
                  APPLI<span className="text-[#00D9FF]">XO</span>
                </div>
                <p className="text-xs text-slate-300">
                  {t('تطبيقات ذكية.. إمكانيات بلا حدود', 'Smart Apps. Limitless Possibilities.')}
                </p>
              </div>
            </div>
          </section>

          {/* Vision & Mission */}
          <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass-surface-elevated rounded-2xl p-7 sm:p-9 space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#087BFF]/15 border border-[#087BFF]/40 flex items-center justify-center text-[#00D9FF]">
                <Compass className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">
                {t('الرؤية', 'Our Vision')}
              </h2>
              <p className="text-base text-slate-300 leading-relaxed">
                {t(
                  'أن تصبح APPLIXO علامة تقنية موثوقة في مجال تطوير تطبيقات Android وتقديم الحلول الرقمية المبتكرة.',
                  'To establish APPLIXO as a trusted technology brand in Android application development and innovative digital solutions.'
                )}
              </p>
            </div>

            <div className="glass-surface-elevated rounded-2xl p-7 sm:p-9 space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#16D65A]/15 border border-[#16D65A]/40 flex items-center justify-center text-[#16D65A]">
                <Target className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">
                {t('الرسالة', 'Our Mission')}
              </h2>
              <p className="text-base text-slate-300 leading-relaxed">
                {t(
                  'تقديم تطبيقات عالية الجودة وتجارب استخدام مميزة تساعد العملاء على الاستفادة من التكنولوجيا.',
                  'Delivering high-quality Android applications and distinctive user experiences that help clients harness technology effectively.'
                )}
              </p>
            </div>
          </section>

          {/* 5 Core Values */}
          <section className="space-y-8">
            <div className="flex items-center gap-3">
              <Award className="w-6 h-6 text-[#00D9FF]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-white">
                {t('قيمنا الأساسية', 'Our Core Values')}
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
              {values.map((val, idx) => (
                <div
                  key={idx}
                  className="glass-surface rounded-2xl p-5 space-y-2.5 hover:border-[#00D9FF]/45 transition-colors"
                >
                  <span className="font-mono-tech text-xs text-[#00D9FF]">0{idx + 1}.</span>
                  <h3 className="text-base font-bold text-white">
                    {t(val.titleAr, val.titleEn)}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t(val.descAr, val.descEn)}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* CTA */}
          <section className="glass-surface rounded-2xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-xl font-bold text-white">
                {t('هل تبحث عن شريك تقني لتطبيقك القادم؟', 'Looking for a Technical Partner for Your Next App?')}
              </h2>
              <p className="text-sm text-slate-300 mt-1">
                {t('استكشف تطبيقاتنا الجاهزة أو تواصل معنا لمناقشة مشروعك.', 'Explore our ready-made store or reach out to discuss your custom idea.')}
              </p>
            </div>
            <div className="flex flex-wrap gap-3 shrink-0">
              <Link
                to="/apps"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#087BFF] hover:brightness-110"
              >
                <span>{t('متجر التطبيقات', 'Apps Store')}</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#020B1D] border border-white/15 hover:border-[#00D9FF]"
              >
                <span>{t('تواصل معنا', 'Contact Us')}</span>
              </Link>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
