import { Link } from 'react-router-dom';
import { Star, Info, ArrowUpRight } from 'lucide-react';
import { TESTIMONIALS_DATA } from '../data/testimonialsData';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';
import { SafeImage } from '../components/SafeImage';

export function TestimonialsPage() {
  const { t } = useLanguage();

  return (
    <>
      <SeoHead
        title={t('آراء العملاء وتجارب الاستخدام', 'Client Testimonials & Experiences')}
        description={t(
          'صفحة آراء العملاء لشركة APPLIXO مع نماذج توضيحية لتجارب العملاء من مختلف الدول العربية.',
          'Client testimonials showcase for APPLIXO Android applications and custom development services.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="max-w-3xl space-y-4 mb-10">
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t('آراء وتجارب العملاء', 'Client Testimonials & Experiences')}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'نؤمن بالشفافية الكاملة مع عملائنا في كل مكان. تعرض هذه الصفحة هيكل بطاقات التقييمات الخاصة بتطبيقات APPLIXO.',
                'We value complete transparency. This showcase presents client feedback cards paired with each Android application.'
              )}
            </p>
          </div>

          {/* Transparency Notice */}
          <div className="rounded-2xl bg-[#07152F]/90 border border-[#00D9FF]/35 p-4 sm:p-5 mb-10 flex items-start gap-3">
            <Info className="w-5 h-5 text-[#00D9FF] shrink-0 mt-0.5" />
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {t(
                'ملاحظة الشفافية: البطاقات المعروضة أدناه هي نماذج توضيحية («تجربة تجريبية») تمثل سيناريوهات استخدام من مصر والسعودية والإمارات والأردن، وسيتم استبدالها تباعًا بتقييمات حقيقية موثقة فور نشرها بإذن أصحابها.',
                'Transparency Notice: The cards below are illustrative sample experiences ("Sample Experience") representing regional use cases across Egypt, Saudi Arabia, UAE, and Jordan, designed to be replaced with verified client reviews upon explicit client permission.'
              )}
            </p>
          </div>

          {/* Individual Client Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TESTIMONIALS_DATA.map((item) => {
              const clientName = t(item.clientNameAr, item.clientNameEn);
              const role = t(item.roleAr, item.roleEn);
              const country = t(item.countryAr, item.countryEn);
              const appName = t(item.appNameAr, item.appNameEn);

              return (
                <article
                  key={item.id}
                  className="glass-surface-elevated rounded-2xl p-6 sm:p-7 flex flex-col justify-between gap-6"
                >
                  <div className="space-y-5">
                    {/* Top Row: Client Avatar + Identity + Clear Sample Label */}
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3.5">
                        <SafeImage
                          src={item.avatar}
                          alt={clientName}
                          className="w-14 h-14 rounded-full object-cover border border-[#00D9FF]/40 shrink-0"
                        />
                        <div>
                          <h2 className="text-base font-bold text-white">{clientName}</h2>
                          <p className="text-xs text-slate-400">{role}</p>
                          <p className="text-xs text-[#00D9FF] font-medium mt-0.5">{country}</p>
                        </div>
                      </div>

                      {item.isSample && (
                        <span className="text-xs font-semibold text-amber-300 border border-amber-400/35 bg-amber-500/10 px-2.5 py-1 rounded-md shrink-0">
                          {t('تجربة تجريبية', 'Sample Experience')}
                        </span>
                      )}
                    </div>

                    {/* Star Rating & Date */}
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-1" aria-label={`${item.rating} / 5`}>
                        {Array.from({ length: 5 }).map((_, idx) => (
                          <Star
                            key={idx}
                            className={`w-4 h-4 ${
                              idx < item.rating
                                ? 'text-amber-400 fill-amber-400'
                                : 'text-slate-600'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-slate-400">
                        {t(item.dateAr, item.dateEn)}
                      </span>
                    </div>

                    {/* Review Quote */}
                    <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
                      “{t(item.reviewAr, item.reviewEn)}”
                    </p>
                  </div>

                  {/* Acquired App Reference + Thumbnail */}
                  <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <SafeImage
                        src={item.appThumbnail}
                        alt={appName}
                        className="w-12 h-10 rounded-lg object-cover border border-white/15 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-[11px] text-slate-400">
                          {t('التطبيق المرتبط', 'Associated App')}
                        </div>
                        <div className="text-xs font-semibold text-white truncate">
                          {appName}
                        </div>
                      </div>
                    </div>

                    <Link
                      to={`/apps/${item.appSlug}`}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#00D9FF] hover:text-white transition-colors shrink-0"
                    >
                      <span>{t('عرض التطبيق', 'View App')}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
