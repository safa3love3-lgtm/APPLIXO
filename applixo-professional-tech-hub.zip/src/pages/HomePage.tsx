import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Store,
  Code2,
  RefreshCw,
  Layers,
  Cpu,
  ShieldCheck,
  CheckCircle2,
  Smartphone,
} from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SERVICES_DATA } from '../data/servicesData';
import { APPS_DATA } from '../data/appsData';
import { SeoHead } from '../components/SeoHead';
import { Phone3DShowcase } from '../components/Phone3DShowcase';
import { AppCard } from '../components/AppCard';

const SERVICE_ICONS = {
  Store,
  Code2,
  RefreshCw,
  Layers,
  Cpu,
  ShieldCheck,
};

export function HomePage() {
  const { t } = useLanguage();

  const featuredApps = APPS_DATA.filter((app) => app.featured).slice(0, 4);

  const whyItems = [
    {
      titleAr: 'تصميمات عصرية',
      titleEn: 'Modern Interfaces',
      descAr: 'واجهات Android واضحة ومبتكرة تراعي أحدث مبادئ تجربة المستخدم وسلاسة الحركة.',
      descEn: 'Crisp, forward-looking Android UI crafted for clarity, visual balance, and fluid motion.',
    },
    {
      titleAr: 'أداء واهتمام بالجودة',
      titleEn: 'Performance & Quality',
      descAr: 'بنية برمجية نظيفة واختبارات دقيقة لضمان سرعة الاستجابة واستقرار التشغيل.',
      descEn: 'Clean Kotlin architecture and thorough QA ensuring responsive frame rates and stability.',
    },
    {
      titleAr: 'حلول مبتكرة',
      titleEn: 'Innovative Solutions',
      descAr: 'توظيف أحدث تقنيات الهاتف والذكاء الاصطناعي لتقديم قيمة فعلية لعملائك.',
      descEn: 'Practical mobile engineering and AI workflows tailored to solve real operational needs.',
    },
    {
      titleAr: 'سهولة الاستخدام',
      titleEn: 'Effortless Usability',
      descAr: 'تدفق شاشات بديهي يدعم اللغتين العربية والإنجليزية ليكون التطبيق مريحًا لكل مستخدم.',
      descEn: 'Intuitive user journeys with native RTL Arabic and LTR English parity out of the box.',
    },
    {
      titleAr: 'دعم فني حسب الاتفاق',
      titleEn: 'Flexible Technical Support',
      descAr: 'خطط صيانة وتحديث مرنة حسب الاتفاق لضمان استمرارية التطبيق وتوافقه المستمر.',
      descEn: 'Tailored maintenance and update agreements to keep your app compatible as Android evolves.',
    },
    {
      titleAr: 'التعامل مع العملاء من جميع أنحاء العالم',
      titleEn: 'Serving Clients Worldwide',
      descAr: 'نتواصل وننفذ ونُسلّم المشاريع للأفراد والشركات في العالم العربي وجميع أنحاء العالم.',
      descEn: 'Seamless remote collaboration, transparent milestones, and delivery across global markets.',
    },
  ];

  return (
    <>
      <SeoHead
        title={t(
          'APPLIXO – تطبيقات ذكية.. إمكانيات بلا حدود | تطوير وبيع تطبيقات Android',
          'APPLIXO – Smart Apps. Limitless Possibilities. | Android App Studio & Store'
        )}
        description={t(
          'APPLIXO شركة متخصصة في تطوير وبيع تطبيقات Android الجاهزة وبرمجة التطبيقات حسب الطلب وتصميم واجهات UI/UX وحلول الذكاء الاصطناعي.',
          'APPLIXO builds and sells ready-made Android applications, custom mobile software, UI/UX systems, and AI-powered solutions worldwide.'
        )}
      />

      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-28 pb-20 lg:pt-36 lg:pb-28 bg-tech-grid">
        <div className="absolute inset-0 bg-circuit-radial pointer-events-none" aria-hidden="true" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
            {/* Hero Copy */}
            <div className="lg:col-span-6 space-y-7">
              <div className="flex items-center gap-4">
                <img
                  src={SITE_CONFIG.logoUrl}
                  alt="APPLIXO Official Logo"
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover border-2 border-[#00D9FF]/50 shadow-[0_0_32px_rgba(0,217,255,0.3)]"
                />
                <div>
                  <div className="font-display-en text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                    APPLI<span className="text-[#00D9FF]">XO</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#16D65A] font-medium mt-1">
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>{t('متخصصون في تطبيقات Android', 'Android Engineering & Apps Store')}</span>
                  </div>
                </div>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-[52px] font-extrabold text-white leading-[1.2] text-balance">
                {t(
                  'تطبيقات ذكية.. إمكانيات بلا حدود.',
                  'Smart Apps. Limitless Possibilities.'
                )}
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl">
                {t(
                  'نحوّل أفكارك إلى تطبيقات Android مبتكرة تجمع بين التصميم العصري والأداء القوي وسهولة الاستخدام.',
                  'We transform your ideas into innovative Android applications combining modern design, powerful performance, and seamless usability.'
                )}
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link
                  to="/apps"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-[#087BFF] to-[#00A8FF] hover:brightness-110 shadow-[0_0_28px_rgba(8,123,255,0.45)] transition-all whitespace-nowrap"
                >
                  <span>{t('استكشف تطبيقاتنا', 'Explore Our Apps')}</span>
                  <ArrowUpRight className="w-4 h-4" />
                </Link>

                <Link
                  to="/custom-development"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-[#07152F]/90 border border-[#00D9FF]/40 hover:border-[#00D9FF] hover:bg-[#0B2046] transition-all whitespace-nowrap"
                >
                  <span>{t('اطلب تطبيقك الآن', 'Order Your App Now')}</span>
                </Link>
              </div>

              <p className="text-xs font-display-en text-slate-400 tracking-wide pt-1">
                Your Ideas. Our Technology. Endless Possibilities.
              </p>
            </div>

            {/* Hero 3D Android Smartphone Visual */}
            <div className="lg:col-span-6">
              <Phone3DShowcase
                image={SITE_CONFIG.heroShowcaseImage}
                alt={t(
                  'عرض ثلاثي الأبعاد لهاتف Android يعرض تطبيقات APPLIXO',
                  '3D Android smartphone displaying APPLIXO smart applications'
                )}
                accentHex="#087BFF"
                badgeText="Android 15"
                className="max-w-xl mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 2. ABOUT SECTION */}
      <section className="py-20 border-t border-white/10 bg-[#040F26]/60">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-2xl sm:text-4xl font-bold text-white">
            {t('من نحن؟', 'Who We Are')}
          </h2>

          <div className="space-y-4 text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl mx-auto">
            <p>
              {t(
                'APPLIXO شركة متخصصة في تطوير وبيع تطبيقات Android، نعمل على تقديم حلول رقمية مبتكرة تساعد الأفراد والشركات على تحقيق أفكارهم وتحويلها إلى تطبيقات عملية.',
                'APPLIXO is a specialized company in developing and selling Android applications, dedicated to delivering innovative digital solutions that help individuals and businesses turn their ideas into practical apps.'
              )}
            </p>
            <p className="text-slate-400">
              {t(
                'نؤمن أن التكنولوجيا ليست مجرد أدوات، بل وسيلة لصناعة تجارب أفضل وتوفير حلول ذكية تلبي احتياجات المستخدمين.',
                'We believe technology is not merely a set of tools, but a means to craft better experiences and deliver smart solutions that truly serve users.'
              )}
            </p>
          </div>

          <div className="pt-2">
            <Link
              to="/about"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#00D9FF] hover:text-white transition-colors"
            >
              <span>{t('اكتشف رؤيتنا وقيمنا', 'Discover Our Vision & Values')}</span>
              <ArrowUpRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 3. SERVICES SECTION */}
      <section className="py-20 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
            <div className="space-y-2">
              <h2 className="text-2xl sm:text-4xl font-bold text-white">
                {t('خدماتنا', 'Our Services')}
              </h2>
              <p className="text-sm sm:text-base text-slate-400 max-w-2xl">
                {t(
                  'منظومة متكاملة لتطوير وإطلاق تطبيقات Android باحترافية عالية.',
                  'An end-to-end engineering suite for building, launching, and scaling Android apps.'
                )}
              </p>
            </div>
            <Link
              to="/services"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#00D9FF] hover:text-white transition-colors whitespace-nowrap"
            >
              <span>{t('تفاصيل الخدمات', 'All Services')}</span>
              <ArrowUpRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES_DATA.map((service) => {
              const Icon = SERVICE_ICONS[service.iconName];
              return (
                <div
                  key={service.id}
                  className="glass-surface rounded-2xl p-6 hover:border-[#00D9FF]/45 transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between gap-5"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-11 h-11 rounded-xl bg-[#087BFF]/15 border border-[#087BFF]/35 flex items-center justify-center text-[#00D9FF]">
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-mono-tech text-xs text-slate-400">
                        {service.number}.
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white">
                      {t(service.titleAr, service.titleEn)}
                    </h3>

                    <p className="text-sm text-slate-300 leading-relaxed">
                      {t(service.shortDescAr, service.shortDescEn)}
                    </p>
                  </div>

                  <Link
                    to="/services"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#00D9FF] hover:text-white transition-colors"
                  >
                    <span>{t('عرض التفاصيل', 'Learn More')}</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. FEATURED APPS SECTION */}
      <section className="py-20 border-t border-white/10 bg-[#040F26]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
            <div className="space-y-2">
              <h2 className="text-2xl sm:text-4xl font-bold text-white">
                {t('التطبيقات المميزة', 'Featured Android Apps')}
              </h2>
              <p className="text-sm sm:text-base text-slate-400 max-w-2xl">
                {t(
                  'مجموعة مختارة من تطبيقات Android التي طورتها APPLIXO وتم بيعها، ويمكن طلب نسخ مخصصة مشابهة لها.',
                  'Curated production-grade Android apps engineered and sold by APPLIXO, available for custom-tailored similar builds.'
                )}
              </p>
            </div>
            <Link
              to="/apps"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#07152F] border border-[#087BFF]/40 hover:border-[#00D9FF] transition-colors whitespace-nowrap"
            >
              <span>{t('تصفح جميع التطبيقات', 'Browse All Apps')}</span>
              <ArrowUpRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-6">
            {featuredApps.map((app) => (
              <AppCard key={app.slug} app={app} />
            ))}
          </div>
        </div>
      </section>

      {/* 5. WHY CHOOSE APPLIXO SECTION */}
      <section className="py-20 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
            <h2 className="text-2xl sm:text-4xl font-bold text-white">
              {t('لماذا تختار APPLIXO؟', 'Why Choose APPLIXO?')}
            </h2>
            <p className="text-sm sm:text-base text-slate-400">
              {t(
                'نلتزم بمعايير هندسية وبصرية دقيقة في كل تطبيق نطوره.',
                'Strict engineering and design standards built into every application we deliver.'
              )}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {whyItems.map((item, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-[#07152F]/60 border border-white/10 p-6 space-y-3 hover:border-[#087BFF]/45 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#16D65A] shrink-0" />
                  <h3 className="text-base font-bold text-white">
                    {t(item.titleAr, item.titleEn)}
                  </h3>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {t(item.descAr, item.descEn)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. CALL TO ACTION SECTION */}
      <section className="py-20 border-t border-white/10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="glass-surface-elevated rounded-3xl p-8 sm:p-14 text-center space-y-6">
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white text-balance">
              {t('هل لديك فكرة تطبيق؟', 'Have an App Idea?')}
            </h2>
            <p className="text-base sm:text-xl text-slate-300 max-w-xl mx-auto">
              {t(
                'دعنا نحول فكرتك إلى مشروع حقيقي.',
                'Let us turn your idea into a real, high-performing Android project.'
              )}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <Link
                to="/custom-development"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-[#087BFF] to-[#00D9FF] hover:brightness-110 shadow-[0_0_28px_rgba(8,123,255,0.45)] transition-all"
              >
                <span>{t('ابدأ مشروعك الآن', 'Start Your Project Now')}</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-7 py-4 rounded-xl text-sm font-semibold text-slate-200 bg-[#020B1D] border border-white/15 hover:border-[#00D9FF] transition-colors"
              >
                <span>{t('تواصل معنا مباشرة', 'Contact Us Directly')}</span>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
