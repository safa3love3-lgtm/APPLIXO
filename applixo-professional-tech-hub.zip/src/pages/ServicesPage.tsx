import { Link } from 'react-router-dom';
import {
  Store,
  Code2,
  RefreshCw,
  Layers,
  Cpu,
  ShieldCheck,
  Check,
  ArrowUpRight,
  MessageCircle,
} from 'lucide-react';
import { SERVICES_DATA } from '../data/servicesData';
import { buildWhatsAppUrl } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';

const SERVICE_ICONS = {
  Store,
  Code2,
  RefreshCw,
  Layers,
  Cpu,
  ShieldCheck,
};

export function ServicesPage() {
  const { t } = useLanguage();

  return (
    <>
      <SeoHead
        title={t('خدماتنا – حلول وتطوير تطبيقات Android', 'Services – Android Engineering & Solutions')}
        description={t(
          'تعرف على خدمات APPLIXO: بيع تطبيقات Android الجاهزة، البرمجة حسب الطلب، تطوير وتحديث التطبيقات، تصميم UI/UX، وحلول الذكاء الاصطناعي.',
          'Explore APPLIXO services: ready-made Android apps, custom development, app modernization, UI/UX design, AI solutions, and flexible support.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4 mb-14">
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t('خدمات APPLIXO المتخصصة', 'Specialized APPLIXO Services')}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'نقدم حلولًا متكاملة لتطوير وإطلاق وصيانة تطبيقات Android للأفراد والشركات في جميع أنحاء العالم.',
                'End-to-end Android engineering, ready-to-launch products, UI/UX design, and AI integration for global clients.'
              )}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SERVICES_DATA.map((service) => {
              const Icon = SERVICE_ICONS[service.iconName];
              const waMsg = t(
                `مرحبًا فريق APPLIXO، أرغب في الاستفسار عن خدمة: ${service.titleAr}`,
                `Hello APPLIXO team, I would like to inquire about: ${service.titleEn}`
              );

              return (
                <article
                  key={service.id}
                  className="glass-surface-elevated rounded-2xl p-6 sm:p-8 flex flex-col justify-between gap-6"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-xl bg-[#087BFF]/15 border border-[#087BFF]/40 flex items-center justify-center text-[#00D9FF]">
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="font-mono-tech text-sm font-semibold text-slate-400">
                        {service.number}
                      </span>
                    </div>

                    <h2 className="text-xl sm:text-2xl font-bold text-white">
                      {t(service.titleAr, service.titleEn)}
                    </h2>

                    <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                      {t(service.detailsAr, service.detailsEn)}
                    </p>

                    <div className="pt-3 border-t border-white/10 space-y-2">
                      <div className="text-xs font-semibold text-[#00D9FF]">
                        {t('أبرز المخرجات:', 'Key Deliverables:')}
                      </div>
                      <ul className="space-y-2">
                        {t(service.deliverablesAr, service.deliverablesEn).map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-300">
                            <Check className="w-4 h-4 text-[#16D65A] shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <a
                      href={buildWhatsAppUrl(waMsg)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-[#020B1D] bg-[#16D65A] hover:brightness-110 transition-all"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{t('استفسار عبر WhatsApp', 'Inquire via WhatsApp')}</span>
                    </a>
                    <Link
                      to="/custom-development"
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#020B1D] border border-white/15 hover:border-[#00D9FF] transition-colors"
                    >
                      <span>{t('طلب عرض سعر', 'Request a Quote')}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
