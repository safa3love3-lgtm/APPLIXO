import { Link } from 'react-router-dom';
import { SITE_CONFIG } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';

export function PrivacyPolicyPage() {
  const { t } = useLanguage();

  return (
    <>
      <SeoHead
        title={t('سياسة الخصوصية – APPLIXO', 'Privacy Policy – APPLIXO')}
        description={t(
          'سياسة الخصوصية لموقع شركة APPLIXO لتطوير وبيع تطبيقات Android.',
          'Privacy Policy for the official APPLIXO Android applications and software studio website.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="glass-surface-elevated rounded-3xl p-6 sm:p-10 space-y-6">
            <h1 className="text-3xl font-extrabold text-white">
              {t('سياسة الخصوصية', 'Privacy Policy')}
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              {t(
                'تحترم شركة APPLIXO خصوصية جميع زوار موقعها الرسمي. لا يتطلب تصفح الموقع أو استعراض التطبيقات إنشاء حساب مستخدم أو تسجيل دخول أو تقديم كلمات مرور.',
                'APPLIXO respects the privacy of all visitors to our official website. Browsing our catalog, viewing app details, or submitting inquiries requires no user account, login, or password creation.'
              )}
            </p>

            <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('1. البيانات التي نجمعها طوعيًا', '1. Information You Voluntarily Provide')}
                </h2>
                <p>
                  {t(
                    'عند تواصلك معنا عبر نموذج التواصل أو البريد الإلكتروني أو WhatsApp، نستخدم بياناتك (الاسم، البريد الإلكتروني، تفاصيل المشروع) فقط للرد على استفسارك وتقديم عرض السعر أو الدعم المطلوب.',
                    'When you reach out via our contact form, email, or WhatsApp, we use your provided details (name, email, and project brief) solely to respond to your inquiry and deliver requested quotes or support.'
                  )}
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('2. عدم مشاركة أو بيع البيانات', '2. No Data Selling or Unauthorized Sharing')}
                </h2>
                <p>
                  {t(
                    'لا تبيع APPLIXO بيانات التواصل الخاصة بالعملاء ولا تشاركها مع أطراف تسويقية خارجية.',
                    'APPLIXO never sells client contact information or shares inquiry details with third-party marketing brokers.'
                  )}
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('3. تفضيل اللغة المحلي', '3. Local Language Preference')}
                </h2>
                <p>
                  {t(
                    'يستخدم الموقع مساحة التخزين المحلية في المتصفح لحفظ اختيارك للغة العربية أو الإنجليزية فقط لتحسين تجربة التصفح.',
                    'Our website stores your selected language preference (Arabic or English) in your browser local storage solely to preserve your reading direction.'
                  )}
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('4. التواصل بخصوص الخصوصية', '4. Privacy Inquiries')}
                </h2>
                <p>
                  {t(
                    `لأي استفسار حول الخصوصية، راسلنا على ${SITE_CONFIG.contact.email}.`,
                    `For any privacy-related questions, contact us at ${SITE_CONFIG.contact.email}.`
                  )}
                </p>
              </section>
            </div>

            <div className="pt-4 border-t border-white/10">
              <Link to="/contact" className="text-xs font-semibold text-[#00D9FF] hover:text-white">
                {t('الانتقال إلى صفحة التواصل', 'Go to Contact Page')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export function TermsOfUsePage() {
  const { t } = useLanguage();

  return (
    <>
      <SeoHead
        title={t('شروط الاستخدام – APPLIXO', 'Terms of Use – APPLIXO')}
        description={t(
          'شروط استخدام الموقع الرسمي لشركة APPLIXO وطلبات شراء وتطوير تطبيقات Android.',
          'Terms of Use for the official APPLIXO website, Android app licenses, and custom development inquiries.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="glass-surface-elevated rounded-3xl p-6 sm:p-10 space-y-6">
            <h1 className="text-3xl font-extrabold text-white">
              {t('شروط الاستخدام', 'Terms of Use')}
            </h1>

            <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('1. طبيعة الخدمات المعروضة', '1. Scope of Services & Licensing')}
                </h2>
                <p>
                  {t(
                    'يعرض موقع APPLIXO معلومات ومواصفات التطبيقات الجاهزة وخدمات برمجة تطبيقات Android حسب الطلب. يتم تأكيد أي عملية شراء أو ترخيص أو مشروع مخصص عبر اتفاق واضح ومكتوب مع العميل.',
                    'The APPLIXO website showcases specifications for ready-made Android applications and custom engineering services. All purchases, white-label licenses, and custom builds are finalized via clear written agreement with the client.'
                  )}
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('2. حقوق الملكية الفكرية', '2. Intellectual Property')}
                </h2>
                <p>
                  {t(
                    'جميع الشعارات والتصميمات ونماذج العرض المنشورة على هذا الموقع مملوكة لشركة APPLIXO، ويخضع استخدام الكود المصدري أو النسخ المخصصة لشروط الترخيص المتفق عليها لكل منتج.',
                    'All APPLIXO trademarks, UI designs, and showcase materials remain the property of APPLIXO. Source code and custom app usage rights follow the specific license agreed upon per purchase.'
                  )}
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-lg font-bold text-white">
                  {t('3. الأسعار والدعم الفني', '3. Pricing & Technical Support')}
                </h2>
                <p>
                  {t(
                    'قد تختلف أسعار التخصيص الإضافي وفق المتطلبات الخاصة بكل عميل، وتخضع خدمات الصيانة والدعم الفني للاتفاق المحدد مع العميل.',
                    'Additional customization pricing may vary depending on bespoke client requirements, and maintenance/support services are provided according to the agreed plan.'
                  )}
                </p>
              </section>
            </div>

            <div className="pt-4 border-t border-white/10">
              <Link to="/apps" className="text-xs font-semibold text-[#00D9FF] hover:text-white">
                {t('تصفح متجر التطبيقات', 'Browse Apps Store')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
