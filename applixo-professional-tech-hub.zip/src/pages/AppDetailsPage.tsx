import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  MessageCircle,
  Play,
  Pause,
  Share2,
  Smartphone,
  Cpu,
  HardDrive,
  Layers,
} from 'lucide-react';
import { APPS_DATA } from '../data/appsData';
import { buildWhatsAppUrl, getActiveBaseUrl } from '../config/siteConfig';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';
import { Phone3DShowcase } from '../components/Phone3DShowcase';

export function AppDetailsPage() {
  const { slug } = useParams<{ slug: string }>();
  const { lang, t } = useLanguage();

  const app = APPS_DATA.find((item) => item.slug === slug);

  const [activeScreenIdx, setActiveScreenIdx] = useState(0);
  const [isPlayingDemo, setIsPlayingDemo] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);

  useEffect(() => {
    setActiveScreenIdx(0);
    setIsPlayingDemo(false);
  }, [slug]);

  useEffect(() => {
    if (!isPlayingDemo || !app || app.screens.length <= 1) return;
    const timer = window.setInterval(() => {
      setActiveScreenIdx((prev) => (prev + 1) % app.screens.length);
    }, 2600);
    return () => window.clearInterval(timer);
  }, [isPlayingDemo, app]);

  if (!app) {
    return (
      <div className="pt-32 pb-24 min-h-screen max-w-3xl mx-auto px-4 text-center space-y-5">
        <SeoHead
          title={t('التطبيق غير موجود', 'App Not Found')}
          description={t('عذرًا، لم يتم العثور على التطبيق المطلوب.', 'The requested Android app could not be found.')}
        />
        <h1 className="text-3xl font-bold text-white">
          {t('التطبيق غير موجود', 'Application Not Found')}
        </h1>
        <p className="text-slate-400">
          {t(
            'قد يكون الرابط غير صحيح أو تم تحديث بيانات التطبيق.',
            'The link may be outdated or the application was moved.'
          )}
        </p>
        <Link
          to="/apps"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#087BFF] text-white text-sm font-semibold"
        >
          <span>{t('العودة إلى التطبيقات', 'Back to Apps')}</span>
        </Link>
      </div>
    );
  }

  const name = t(app.nameAr, app.nameEn);
  const tagline = t(app.taglineAr, app.taglineEn);
  const category = t(app.categoryAr, app.categoryEn);
  const fullDesc = t(app.fullDescAr, app.fullDescEn);
  const features = t(app.featuresAr, app.featuresEn);
  const requirements = t(app.requirementsAr, app.requirementsEn);
  const statusText = t('تم البيع', 'Sold');

  const activeScreen = app.screens[activeScreenIdx] || app.screens[0];

  const shareUrl = `${getActiveBaseUrl()}/apps/${app.slug}`;

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `${name} | APPLIXO`,
          text: tagline,
          url: shareUrl,
        });
        return;
      }
      await navigator.clipboard.writeText(shareUrl);
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2500);
    } catch {
      try {
        await navigator.clipboard.writeText(shareUrl);
        setShareCopied(true);
        setTimeout(() => setShareCopied(false), 2500);
      } catch {
        // Ignore clipboard denial
      }
    }
  };

  const waMessage = t(
    `مرحبًا فريق APPLIXO، اطلعت على تطبيق "${app.nameAr}" وأرغب في الاستفسار عن تطوير نسخة مماثلة لمشروعي. رابط التطبيق: ${shareUrl}`,
    `Hello APPLIXO team, I viewed "${app.nameEn}" and would like to inquire about building a similar custom app. App link: ${shareUrl}`
  );

  const customOrderSteps = t(
    [
      'تواصل معنا عبر WhatsApp لمناقشة فكرة النسخة المخصصة لمشروعك.',
      'تحديد الهوية التجارية والمميزات المطلوبة والمدة الزمنية.',
      'التنفيذ والاختبار وتسليم التطبيق جاهزًا للنشر باسمك.',
    ],
    [
      'Connect via WhatsApp to discuss a tailored version for your brand.',
      'Finalize visual branding, custom features, and delivery timeline.',
      'Receive your tested, store-ready Android build under your own name.',
    ]
  );

  const BackIcon = lang === 'ar' ? ArrowRight : ArrowLeft;

  return (
    <>
      <SeoHead
        title={`${name} – ${tagline}`}
        description={t(app.shortDescAr, app.shortDescEn)}
        image={app.image}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb Back */}
          <div className="mb-8 flex items-center justify-between gap-4 flex-wrap">
            <Link
              to="/apps"
              className="inline-flex items-center gap-2 text-sm text-slate-300 hover:text-[#00D9FF] transition-colors"
            >
              <BackIcon className="w-4 h-4" />
              <span>{t('العودة إلى التطبيقات', 'Back to Apps')}</span>
            </Link>

            <button
              type="button"
              onClick={handleShare}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium bg-[#07152F] border border-[#087BFF]/35 text-slate-200 hover:border-[#00D9FF] transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-[#00D9FF]" />
              <span>
                {shareCopied
                  ? t('تم نسخ رابط التطبيق!', 'App Link Copied!')
                  : t('مشاركة رابط التطبيق', 'Share App Link')}
              </span>
            </button>
          </div>

          {/* Main Product Split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Visual Showcase + Multi-screen Gallery */}
            <div className="lg:col-span-6 space-y-6">
              <Phone3DShowcase
                image={app.image}
                alt={name}
                accentHex={app.accentHex}
                badgeText={app.androidVersion}
              />

              {/* Multi-Screen Interactive App Walkthrough */}
              {app.screens.length > 0 && (
                <div className="glass-surface rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <h3 className="text-sm font-bold text-white">
                      {t('استعراض الشاشات الداخلية للتطبيق', 'Inside the App Screens')}
                    </h3>
                    {app.hasInteractiveVideoPreview && app.screens.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setIsPlayingDemo((p) => !p)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#087BFF]/20 border border-[#087BFF]/40 text-[#00D9FF] hover:bg-[#087BFF]/30 transition-colors cursor-pointer"
                      >
                        {isPlayingDemo ? (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            <span>{t('إيقاف العرض التلقائي', 'Pause Walkthrough')}</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>{t('تشغيل عرض استعراضي', 'Play App Walkthrough')}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {/* Screen Tabs */}
                  <div className="flex flex-wrap gap-2">
                    {app.screens.map((scr, idx) => (
                      <button
                        key={scr.id}
                        type="button"
                        onClick={() => {
                          setIsPlayingDemo(false);
                          setActiveScreenIdx(idx);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                          activeScreenIdx === idx
                            ? 'bg-[#087BFF] text-white'
                            : 'bg-[#020B1D] text-slate-300 border border-white/10 hover:border-[#00D9FF]/40'
                        }`}
                      >
                        {t(scr.titleAr, scr.titleEn)}
                      </button>
                    ))}
                  </div>

                  {/* Active Inner Screen Preview Panel */}
                  {activeScreen && (
                    <div className="rounded-xl bg-[#020B1D] border border-white/10 p-4 space-y-4">
                      <div>
                        <div className="text-sm font-bold text-white">
                          {t(activeScreen.titleAr, activeScreen.titleEn)}
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          {t(activeScreen.subtitleAr, activeScreen.subtitleEn)}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        {activeScreen.metrics.map((m, i) => (
                          <div
                            key={i}
                            className="rounded-lg bg-[#07152F] border border-white/10 p-3"
                          >
                            <div className="text-[11px] text-slate-400">
                              {t(m.labelAr, m.labelEn)}
                            </div>
                            <div className="font-mono-tech text-base font-bold text-[#00D9FF] mt-0.5">
                              {m.value}
                            </div>
                          </div>
                        ))}
                      </div>

                      <ul className="space-y-1.5">
                        {t(activeScreen.highlightsAr, activeScreen.highlightsEn).map((hl, i) => (
                          <li key={i} className="flex items-center gap-2 text-xs text-slate-300">
                            <Check className="w-3.5 h-3.5 text-[#16D65A] shrink-0" />
                            <span>{hl}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Technical Details & Similar Build CTA */}
            <div className="lg:col-span-6 space-y-6">
              <div className="glass-surface-elevated rounded-2xl p-6 sm:p-8 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="text-[#00D9FF] font-semibold">{category}</span>
                  <span className="font-semibold text-amber-300">{statusText}</span>
                </div>

                <div className="space-y-2">
                  <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
                    {name}
                  </h1>
                  <p className="text-base text-slate-300">{tagline}</p>
                </div>

                {/* Status & Primary WhatsApp Action (No Price) */}
                <div className="pt-4 pb-5 border-y border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-400">
                      {t('حالة التطبيق', 'Availability Status')}
                    </div>
                    <div className="text-lg font-bold text-amber-300 mt-0.5">
                      {t('تم البيع بالكامل · متاح تنفيذ نسخة مخصصة', 'Sold · Custom Build Available')}
                    </div>
                  </div>

                  <a
                    href={buildWhatsAppUrl(waMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl text-sm font-bold text-[#020B1D] bg-[#16D65A] hover:brightness-110 shadow-[0_0_24px_rgba(22,214,90,0.3)] transition-all whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>
                      {t('اطلب نسخة مماثلة عبر WhatsApp', 'Request Similar via WhatsApp')}
                    </span>
                  </a>
                </div>

                {/* Detailed Description */}
                <div className="space-y-2">
                  <h2 className="text-base font-bold text-white">
                    {t('وصف التطبيق', 'Application Overview')}
                  </h2>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {fullDesc}
                  </p>
                </div>

                {/* Key Android Tech Specs */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="rounded-xl bg-[#020B1D] border border-white/10 p-3.5">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Smartphone className="w-3.5 h-3.5 text-[#16D65A]" />
                      <span>{t('إصدار Android', 'Android Support')}</span>
                    </div>
                    <div className="font-mono-tech text-xs font-semibold text-white mt-1.5">
                      {app.androidVersion}
                    </div>
                  </div>
                  <div className="rounded-xl bg-[#020B1D] border border-white/10 p-3.5">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Cpu className="w-3.5 h-3.5 text-[#00D9FF]" />
                      <span>{t('البنية البرمجية', 'Architecture')}</span>
                    </div>
                    <div className="font-mono-tech text-xs font-semibold text-white mt-1.5 truncate">
                      {app.minSdk}
                    </div>
                  </div>
                  <div className="rounded-xl bg-[#020B1D] border border-white/10 p-3.5">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <HardDrive className="w-3.5 h-3.5 text-[#087BFF]" />
                      <span>{t('حجم الحزمة', 'Package Size')}</span>
                    </div>
                    <div className="font-mono-tech text-xs font-semibold text-white mt-1.5">
                      {app.packageSize}
                    </div>
                  </div>
                </div>
              </div>

              {/* Features & Characteristics */}
              <div className="glass-surface rounded-2xl p-6 space-y-4">
                <h2 className="text-lg font-bold text-white">
                  {t('المميزات والخصائص', 'Features & Capabilities')}
                </h2>
                <ul className="space-y-2.5">
                  {features.map((feat, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                      <Check className="w-4 h-4 text-[#16D65A] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* System Requirements & Custom Order Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-surface rounded-2xl p-6 space-y-3">
                  <h2 className="text-base font-bold text-white">
                    {t('متطلبات التشغيل', 'System Requirements')}
                  </h2>
                  <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
                    {requirements.map((req, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-[#00D9FF]">·</span>
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="glass-surface rounded-2xl p-6 space-y-3">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#00D9FF]" />
                    <h2 className="text-base font-bold text-white">
                      {t('طلب نسخة مخصصة مشابهة', 'Request a Custom Version')}
                    </h2>
                  </div>
                  <ol className="space-y-2 text-xs sm:text-sm text-slate-300">
                    {customOrderSteps.map((step, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono-tech text-[#00D9FF] font-semibold">
                          0{i + 1}.
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
