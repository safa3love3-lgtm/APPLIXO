import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, ArrowUpRight, Layers } from 'lucide-react';
import { PORTFOLIO_PROJECTS } from '../data/portfolioData';
import { useLanguage } from '../context/LanguageContext';
import { SeoHead } from '../components/SeoHead';
import { Phone3DShowcase } from '../components/Phone3DShowcase';

export function PortfolioPage() {
  const { t } = useLanguage();
  const [selectedScreens, setSelectedScreens] = useState<Record<string, number>>({});

  const getActiveScreenIdx = (projectId: string) => selectedScreens[projectId] ?? 0;

  return (
    <>
      <SeoHead
        title={t('أعمالنا – معرض تطبيقات Android', 'Portfolio – Android Projects Showcase')}
        description={t(
          'معرض أعمال شركة APPLIXO لتطبيقات Android المطورة بتصميمات ثلاثية الأبعاد وواجهات داخلية عصرية.',
          'Explore APPLIXO Android portfolio featuring 3D mobile showcases, clean architecture, and interactive screen galleries.'
        )}
      />

      <div className="pt-28 pb-24 min-h-screen bg-tech-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="max-w-3xl space-y-4 mb-14">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-[#00D9FF]">
              <Layers className="w-4 h-4" />
              <span>{t('معرض المشاريع والتطبيقات', 'Developed Mobile Showcase')}</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white text-balance">
              {t('أعمالنا في تطوير تطبيقات Android', 'Our Android Engineering Portfolio')}
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              {t(
                'نماذج متنوعة من تطبيقات Android التي صممناها وبرمجناها بهويات بصرية مختلفة وواجهات داخلية متقنة.',
                'A diverse collection of Android applications engineered with distinct visual identities, smooth interactions, and tailored UI systems.'
              )}
            </p>
          </div>

          {/* Portfolio 3D Showcase Rows */}
          <div className="space-y-12">
            {PORTFOLIO_PROJECTS.map((project, index) => {
              const activeIdx = getActiveScreenIdx(project.id);
              const activeScreen = project.innerScreens[activeIdx] || project.innerScreens[0];
              const isReversed = index % 2 === 1;

              return (
                <article
                  key={project.id}
                  className="glass-surface-elevated rounded-3xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center"
                >
                  {/* 3D Smartphone Frame */}
                  <div
                    className={`lg:col-span-5 ${
                      isReversed ? 'lg:order-2' : 'lg:order-1'
                    }`}
                  >
                    <Phone3DShowcase
                      image={project.image}
                      alt={t(project.titleAr, project.titleEn)}
                      accentHex={project.accentHex}
                      badgeText={project.androidTarget}
                    />
                  </div>

                  {/* Project Info & Interactive Inner Screens */}
                  <div
                    className={`lg:col-span-7 space-y-5 ${
                      isReversed ? 'lg:order-1' : 'lg:order-2'
                    }`}
                  >
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono-tech text-slate-400">0{index + 1}.</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-[#00D9FF] font-semibold">
                        {t(project.typeAr, project.typeEn)}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-[#16D65A] font-medium">
                        {project.androidTarget}
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl font-bold text-white">
                      {t(project.titleAr, project.titleEn)}
                    </h2>

                    <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                      {t(project.summaryAr, project.summaryEn)}
                    </p>

                    {/* Key Highlights */}
                    <ul className="space-y-2">
                      {t(project.highlightsAr, project.highlightsEn).map((hl, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-sm text-slate-200">
                          <Check className="w-4 h-4 text-[#16D65A] shrink-0 mt-0.5" />
                          <span>{hl}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Inner Screens Switcher */}
                    {project.innerScreens.length > 0 && (
                      <div className="rounded-2xl bg-[#020B1D] border border-white/10 p-4 space-y-3">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-slate-300">
                            {t('الواجهات الداخلية:', 'Inner Screens:')}
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {project.innerScreens.map((scr, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() =>
                                  setSelectedScreens((prev) => ({ ...prev, [project.id]: idx }))
                                }
                                className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                                  activeIdx === idx
                                    ? 'bg-[#087BFF] text-white'
                                    : 'bg-[#07152F] text-slate-300 hover:text-white'
                                }`}
                              >
                                {t(scr.labelAr, scr.labelEn)}
                              </button>
                            ))}
                          </div>
                        </div>

                        {activeScreen && (
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-white/10">
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {t(activeScreen.descriptionAr, activeScreen.descriptionEn)}
                            </p>
                            <div className="shrink-0 text-end">
                              <div className="text-[11px] text-slate-400">
                                {t(activeScreen.metricLabelAr, activeScreen.metricLabelEn)}
                              </div>
                              <div className="font-mono-tech text-sm font-bold text-[#00D9FF]">
                                {activeScreen.metricValue}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="pt-2">
                      <Link
                        to="/custom-development"
                        className="inline-flex items-center gap-2 text-sm font-semibold text-[#00D9FF] hover:text-white transition-colors"
                      >
                        <span>
                          {t('اطلب مشروعًا مشابهًا لفكرتك', 'Request a Similar Custom Project')}
                        </span>
                        <ArrowUpRight className="w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
