export type Language = 'ar' | 'en';

export interface SocialLinkConfig {
  id: string;
  labelAr: string;
  labelEn: string;
  url: string;
}

/**
 * Central site & domain configuration for APPLIXO.
 * Change `targetDomain` here when connecting the production domain.
 */
export const SITE_CONFIG = {
  brandName: 'APPLIXO',
  // Target production custom domain (update here when DNS is connected)
  targetDomain: 'https://applixo.com',
  // Proposed Firebase Hosting temporary domain (active after running firebase deploy)
  firebaseHostingDomain: 'https://applixo.web.app',
  // Active runtime preview/hosting URL fallback when running locally
  temporaryHostingUrl: 'https://ais-dev-fzfaikk7jehgb4hunnlpcu-808531142408.europe-west2.run.app',
  // Official APPLIXO logo asset
  logoUrl: '/assets/aistudio/file_000000006f5c821092c9820bce784df2_f5a5305d.webp',
  heroShowcaseImage: '/src/assets/images/hero_android_showcase_1794951749243.jpg',
  contact: {
    email: 'info@applixo.com',
    whatsappDisplay: '+201152140148',
    whatsappNumberClean: '201152140148',
    whatsappBaseUrl: 'https://wa.me/201152140148',
  },
  // Future social links can be added here when official accounts go live.
  // Empty list ensures no placeholder or non-existent social links are displayed.
  socialLinks: [] as SocialLinkConfig[],
};

/**
 * Resolves the active base URL for shareable links and canonical metadata.
 * Automatically reflects Firebase Hosting (applixo.web.app), AI Studio preview,
 * or the final custom domain (applixo.com) without modifying individual pages.
 */
export function getActiveBaseUrl(): string {
  if (typeof window !== 'undefined' && window.location?.origin) {
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      return SITE_CONFIG.temporaryHostingUrl;
    }
    return window.location.origin;
  }
  return SITE_CONFIG.temporaryHostingUrl;
}

/**
 * Checks whether the current runtime host matches the bound target domain.
 */
export function isTargetDomainActive(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const targetHost = new URL(SITE_CONFIG.targetDomain).hostname.replace(/^www\./, '');
    const currentHost = window.location.hostname.replace(/^www\./, '');
    return currentHost === targetHost;
  } catch {
    return false;
  }
}

/**
 * Builds a direct WhatsApp chat URL with an automatic language-appropriate message.
 */
export function buildWhatsAppUrl(message: string): string {
  return `${SITE_CONFIG.contact.whatsappBaseUrl}?text=${encodeURIComponent(message)}`;
}

/**
 * Builds a mailto link with optional subject and body.
 */
export function buildMailtoUrl(subject?: string, body?: string): string {
  const params = new URLSearchParams();
  if (subject) params.set('subject', subject);
  if (body) params.set('body', body);
  const query = params.toString();
  return `mailto:${SITE_CONFIG.contact.email}${query ? `?${query}` : ''}`;
}
