export interface PortfolioProject {
  id: string;
  titleAr: string;
  titleEn: string;
  typeAr: string;
  typeEn: string;
  summaryAr: string;
  summaryEn: string;
  highlightsAr: string[];
  highlightsEn: string[];
  image: string;
  accentHex: string;
  androidTarget: string;
  innerScreens: {
    labelAr: string;
    labelEn: string;
    metricLabelAr: string;
    metricLabelEn: string;
    metricValue: string;
    descriptionAr: string;
    descriptionEn: string;
  }[];
}

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'bizpulse-enterprise',
    titleAr: 'منصة BizPulse لإدارة الأعمال',
    titleEn: 'BizPulse Business & ERP Suite',
    typeAr: 'تطبيق إدارة أعمال ومبيعات',
    typeEn: 'Enterprise Business & Finance App',
    summaryAr:
      'تم تطوير تطبيق Android متكامل للشركات التجارية يجمع بين متابعة الإيرادات اللحظية، إصدار الفواتير الإلكترونية، ومراقبة المخزون الميداني.',
    summaryEn:
      'Engineered a high-throughput Android ERP companion allowing commercial teams to track real-time revenue, generate digital invoices, and monitor inventory.',
    highlightsAr: [
      'رسوم بيانية تفاعلية للأداء المالي',
      'توليد فواتير PDF ومشاركتها بضغطة زر',
      'مزامنة فورية مع العمل دون اتصال بالإنترنت',
    ],
    highlightsEn: [
      'Interactive real-time revenue charts',
      'One-tap PDF invoice generation & sharing',
      'Offline-first architecture with instant cloud sync',
    ],
    image: '/src/assets/images/app_business_erp_1794951748767.jpg',
    accentHex: '#087BFF',
    androidTarget: 'Android 15 Ready',
    innerScreens: [
      {
        labelAr: 'لوحة الإيرادات',
        labelEn: 'Revenue Analytics',
        metricLabelAr: 'مؤشر الدقة',
        metricLabelEn: 'Sync Speed',
        metricValue: '60 fps',
        descriptionAr: 'عرض بياني واضح للتدفقات النقدية والفواتير المدفوعة والمعلقة.',
        descriptionEn: 'Clean visual breakdown of cashflow, paid invoices, and pending settlements.',
      },
      {
        labelAr: 'إصدار الفواتير',
        labelEn: 'Mobile Invoicing',
        metricLabelAr: 'زمن الإنشاء',
        metricLabelEn: 'Draft Time',
        metricValue: '15 sec',
        descriptionAr: 'نموذج سريع لحساب الضرائب والخصومات وإرسال الفاتورة للعميل.',
        descriptionEn: 'Streamlined builder for taxes, discounts, and instant client dispatch.',
      },
    ],
  },
  {
    id: 'nexus-ai-creative',
    titleAr: 'استوديو Nexus للذكاء الاصطناعي',
    titleEn: 'Nexus AI Creative Studio',
    typeAr: 'تطبيق ذكاء اصطناعي وأتمتة',
    typeEn: 'AI Assistant & Generative Studio',
    summaryAr:
      'بناء واجهة Android مستقبلية للتفاعل مع نماذج الذكاء الاصطناعي عبر النصوص والأوامر الصوتية، مع حفظ وتنظيم المشاريع الإبداعية.',
    summaryEn:
      'Designed and built a sleek Android workspace for streaming AI prompts, voice-driven content drafting, and neural audio visualization.',
    highlightsAr: [
      'بث فوري للردود الذكية بدون انتظار',
      'تحليل الأوامر الصوتية باللغتين العربية والإنجليزية',
      'تأمين الاتصالات عبر خادم وسيط مخصص',
    ],
    highlightsEn: [
      'Real-time streaming response engine',
      'Bilingual Arabic & English voice prompt parsing',
      'Server-proxied secure API architecture',
    ],
    image: '/src/assets/images/app_ai_assistant_1794951750358.jpg',
    accentHex: '#00D9FF',
    androidTarget: 'Android 15 Ready',
    innerScreens: [
      {
        labelAr: 'محرر الأوامر الذكي',
        labelEn: 'Prompt Studio',
        metricLabelAr: 'معدل الاستجابة',
        metricLabelEn: 'Latency',
        metricValue: '400 ms',
        descriptionAr: 'بيئة عمل هادئة لصياغة الأوامر وتوليد المحتوى الاحترافي.',
        descriptionEn: 'Focused workspace for crafting structured prompts and instant drafts.',
      },
      {
        labelAr: 'محلل الصوت الموجي',
        labelEn: 'Neural Audio',
        metricLabelAr: 'دقة التفريغ',
        metricLabelEn: 'Precision',
        metricValue: '98.2%',
        descriptionAr: 'التقاط الصوت وتحويله مباشرة إلى مهام وملخصات منظمة.',
        descriptionEn: 'Live voice capture converted into structured summaries and tasks.',
      },
    ],
  },
  {
    id: 'cinecut-4k-studio',
    titleAr: 'تطبيق CineCut لمونتاج الفيديو 4K',
    titleEn: 'CineCut 4K Video & Color Editor',
    typeAr: 'تطبيق تحرير فيديو وصور',
    typeEn: 'Mobile Video & Photo Editing Suite',
    summaryAr:
      'تطوير محرك مونتاج متنقل يعمل بتسريع العتاد لتعديل الفيديوهات عالية الدقة وتصحيح الألوان بسهولة من شاشة الهاتف.',
    summaryEn:
      'Engineered a hardware-accelerated mobile NLE supporting multi-track timelines, LUT color grading wheels, and smooth 4K export.',
    highlightsAr: [
      'خط زمني سلس يدعم طبقات الفيديو والصوت والنص',
      'عجلات ألوان احترافية لمعالجة الإضاءة والتباين',
      'تصدير سريع بدقة 4K بدون فقدان الجودة',
    ],
    highlightsEn: [
      'Multi-track timeline for video, audio, and titles',
      'Precision color wheels for exposure and grading',
      'High-speed 4K export via Media3 hardware codecs',
    ],
    image: '/src/assets/images/app_video_editor_1794951750043.jpg',
    accentHex: '#F59E0B',
    androidTarget: 'Android 14 / 15',
    innerScreens: [
      {
        labelAr: 'محرر المسارات',
        labelEn: 'Timeline Editor',
        metricLabelAr: 'دقة المعاينة',
        metricLabelEn: 'Playback',
        metricValue: '4K UHD',
        descriptionAr: 'تحكم دقيق في قص المقاطع ومزامنة المسارات الصوتية.',
        descriptionEn: 'Frame-accurate clip trimming and audio track alignment.',
      },
      {
        labelAr: 'معالجة الألوان',
        labelEn: 'Color Grading',
        metricLabelAr: 'فلاتر مدمجة',
        metricLabelEn: 'Presets',
        metricValue: '28 LUTs',
        descriptionAr: 'تعديل التشبع والظلال والإضاءة الساطعة في الوقت الحقيقي.',
        descriptionEn: 'Real-time adjustment of highlights, shadows, and film LUTs.',
      },
    ],
  },
  {
    id: 'krypton-team-messenger',
    titleAr: 'شبكة Krypton للتواصل المشفر',
    titleEn: 'Krypton Encrypted Messenger',
    typeAr: 'تطبيق دردشة وتواصل للفرق',
    typeEn: 'Secure Messaging & Voice App',
    summaryAr:
      'تطبيق محادثات فورية ومكالمات عالية النقاء موجه للفرق التقنية والمؤسسات التي تحتاج خصوصية عالية وأداءً سريعًا.',
    summaryEn:
      'Private Android messaging application built for agile teams requiring encrypted channels, voice notes, and HD WebRTC calls.',
    highlightsAr: [
      'قنوات عمل منظمة مع مؤشرات القراءة الفورية',
      'مكالمات صوتية ومرئية عالية الاستقرار',
      'تشفير متكامل للبيانات والملفات المرسلة',
    ],
    highlightsEn: [
      'Structured group channels with instant delivery status',
      'Stable HD audio & video calling over mobile data',
      'End-to-end encrypted file and message exchange',
    ],
    image: '/src/assets/images/app_chat_comm_1794951751290.jpg',
    accentHex: '#16D65A',
    androidTarget: 'Android 15 Ready',
    innerScreens: [
      {
        labelAr: 'غرف الفريق',
        labelEn: 'Team Threads',
        metricLabelAr: 'تشفير',
        metricLabelEn: 'Encryption',
        metricValue: 'E2EE',
        descriptionAr: 'مناقشات سريعة ومرتبة مع مشاركة الملفات والمستندات.',
        descriptionEn: 'Fast threaded conversations with encrypted document sharing.',
      },
    ],
  },
  {
    id: 'aural-audio-mastering',
    titleAr: 'تطبيق Aural للبث الصوتي عالي النقاء',
    titleEn: 'Aural Hi-Fi Streaming & Mastering',
    typeAr: 'تطبيق صوت وموسيقى',
    typeEn: 'Hi-Fi Audio & Podcast App',
    summaryAr:
      'تجربة استماع فاخرة على Android مع معادل صوتي متقدم وعرض طيفي حي للترددات الصوتية ودعم التشغيل في الخلفية.',
    summaryEn:
      'Studio-grade Android audio platform featuring lossless streaming, a 10-band equalizer, and live spectral visualization.',
    highlightsAr: [
      'معادل ترددات احترافي من 10 نطاقات',
      'عرض طيفي ديناميكي للموجات الصوتية',
      'دعم التحميل المسبق للاستماع دون إنترنت',
    ],
    highlightsEn: [
      '10-band precision graphic equalizer',
      'Dynamic live audio spectrum display',
      'Encrypted offline playback support',
    ],
    image: '/src/assets/images/app_audio_music_1794951750604.jpg',
    accentHex: '#8B5CF6',
    androidTarget: 'Android 14 / 15',
    innerScreens: [
      {
        labelAr: 'المشغل الرئيسي',
        labelEn: 'Spectral Player',
        metricLabelAr: 'جودة البث',
        metricLabelEn: 'Bitrate',
        metricValue: 'Lossless',
        descriptionAr: 'واجهة استماع داكنة هادئة مع تحكم كامل في الترددات.',
        descriptionEn: 'Refined dark listening interface with real-time DSP controls.',
      },
    ],
  },
  {
    id: 'focusflow-productivity',
    titleAr: 'تطبيق FocusFlow لإدارة المهام والتركيز',
    titleEn: 'FocusFlow Daily Planner & Timer',
    typeAr: 'تطبيق أدوات وإنتاجية',
    typeEn: 'Productivity & Time-Blocking App',
    summaryAr:
      'تطبيق عملي لتنظيم المهام اليومية والجدول الزمني مع مؤقت تركيز مدمج يساعد المستخدمين على إنجاز أهدافهم بدون تشتيت.',
    summaryEn:
      'Clean Android productivity suite pairing structured daily task queues with calendar time-blocking and a deep work timer.',
    highlightsAr: [
      'تقسيم المهام والأولويات بوضوح تام',
      'مؤقت جلسات عمل عميقة بتصميم مريح',
      'أداء فائق الخفة واستهلاك منخفض للبطارية',
    ],
    highlightsEn: [
      'Clear daily task and priority separation',
      'Distraction-free focus timer sessions',
      'Ultra-lightweight battery footprint',
    ],
    image: '/src/assets/images/app_productivity_tasks_1794951751526.jpg',
    accentHex: '#16D65A',
    androidTarget: 'Android 15 Ready',
    innerScreens: [
      {
        labelAr: 'جدول المهام والتركيز',
        labelEn: 'Tasks & Focus',
        metricLabelAr: 'الحجم',
        metricLabelEn: 'APK Size',
        metricValue: '15 MB',
        descriptionAr: 'شاشة واحدة تجمع المهام والتقويم ومؤقت الإنجاز.',
        descriptionEn: 'Unified workspace for daily tasks, timeline, and focus timer.',
      },
    ],
  },
];
