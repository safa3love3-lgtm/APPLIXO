export type AppCategoryId =
  | 'all'
  | 'business'
  | 'ai'
  | 'video-photo'
  | 'audio-music'
  | 'chat'
  | 'tools-productivity'
  | 'misc';

export interface AppCategory {
  id: AppCategoryId;
  labelAr: string;
  labelEn: string;
}

export interface AppScreenMockup {
  id: string;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  metrics: { labelAr: string; labelEn: string; value: string }[];
  highlightsAr: string[];
  highlightsEn: string[];
}

export interface AndroidAppItem {
  slug: string;
  nameAr: string;
  nameEn: string;
  taglineAr: string;
  taglineEn: string;
  categoryId: Exclude<AppCategoryId, 'all'>;
  categoryAr: string;
  categoryEn: string;
  status: 'sold';
  featured?: boolean;
  accentHex: string;
  secondaryHex: string;
  image: string;
  androidVersion: string;
  minSdk: string;
  packageSize: string;
  architecture: string;
  shortDescAr: string;
  shortDescEn: string;
  fullDescAr: string;
  fullDescEn: string;
  featuresAr: string[];
  featuresEn: string[];
  requirementsAr: string[];
  requirementsEn: string[];
  purchaseStepsAr: string[];
  purchaseStepsEn: string[];
  hasInteractiveVideoPreview: boolean;
  screens: AppScreenMockup[];
}

export const APP_CATEGORIES: AppCategory[] = [
  { id: 'all', labelAr: 'الكل', labelEn: 'All Apps' },
  { id: 'business', labelAr: 'تطبيقات الأعمال', labelEn: 'Business Apps' },
  { id: 'ai', labelAr: 'تطبيقات الذكاء الاصطناعي', labelEn: 'AI Apps' },
  { id: 'video-photo', labelAr: 'تحرير الفيديو والصور', labelEn: 'Video & Photo Editing' },
  { id: 'audio-music', labelAr: 'الصوت والموسيقى', labelEn: 'Audio & Music' },
  { id: 'chat', labelAr: 'التواصل والدردشة', labelEn: 'Chat & Communication' },
  { id: 'tools-productivity', labelAr: 'الأدوات والإنتاجية', labelEn: 'Tools & Productivity' },
  { id: 'misc', labelAr: 'تطبيقات متنوعة', labelEn: 'Miscellaneous' },
];

export const APPS_DATA: AndroidAppItem[] = [
  {
    slug: 'applixo-bizpulse-erp',
    nameAr: 'BizPulse ERP',
    nameEn: 'BizPulse ERP',
    taglineAr: 'نظام إدارة الأعمال والمبيعات والفواتير الذكي',
    taglineEn: 'Smart Mobile Business, Sales & Invoicing Suite',
    categoryId: 'business',
    categoryAr: 'تطبيقات الأعمال',
    categoryEn: 'Business Apps',
    status: 'sold',
    featured: true,
    accentHex: '#087BFF',
    secondaryHex: '#00D9FF',
    image: '/src/assets/images/app_business_erp_1794951748767.jpg',
    androidVersion: 'Android 9.0 – 15.0',
    minSdk: 'API 28+',
    packageSize: '24 MB',
    architecture: 'Kotlin + Jetpack Compose + MVVM',
    shortDescAr:
      'تطبيق متكامل لإدارة الفواتير، المبيعات، المخزون، وتقارير الأرباح الفورية مع دعم العمل بدون إنترنت.',
    shortDescEn:
      'All-in-one Android app for invoicing, inventory tracking, sales analytics, and offline-first sync.',
    fullDescAr:
      'صُمم تطبيق BizPulse ERP لرواد الأعمال والشركات الصغيرة والمتوسطة لإدارة العمليات اليومية من الهاتف بسلاسة تامة. يجمع التطبيق بين إصدار الفواتير الفوري، متابعة حركة المخزون، تقارير الأداء المالي، وإدارة صلاحيات الموظفين في واجهة عربية وإنجليزية متكاملة.',
    fullDescEn:
      'BizPulse ERP empowers founders and SMEs to run daily commercial operations right from Android. It combines instant invoice generation, inventory control, financial analytics, and team access management inside a crisp bilingual RTL/LTR interface.',
    featuresAr: [
      'لوحة تقارير مالية تفاعلية للمبيعات والأرباح الشهرية',
      'إصدار فواتير PDF ومشاركتها مباشرة عبر WhatsApp والبريد',
      'إدارة المخزون مع تنبيهات انخفاض الكميات',
      'مزامنة ذكية للبيانات مع دعم الوضع غير المتصل (Offline)',
      'دعم تعدد العملات والضرائب القابل للتخصيص',
      'دعم كامل للغة العربية والإنجليزية RTL / LTR',
    ],
    featuresEn: [
      'Interactive financial dashboards for revenue and net margin',
      'Instant PDF invoice generation with WhatsApp & email sharing',
      'Real-time stock tracking with low-inventory alerts',
      'Offline-first local Room cache with cloud synchronization',
      'Multi-currency and configurable tax calculation rules',
      'Native Arabic & English RTL/LTR interface',
    ],
    requirementsAr: [
      'نظام Android 9.0 أو أحدث',
      'ذاكرة وصول عشوائي 3 جيجابايت فأكثر',
      'مساحة تخزين فارغة 100 ميجابايت',
      'دعم الاتصال بالإنترنت للمزامنة السحابية',
    ],
    requirementsEn: [
      'Android 9.0 (Pie) or higher',
      'Minimum 3 GB RAM recommended',
      '100 MB available internal storage',
      'Internet connection for cloud sync',
    ],
    purchaseStepsAr: [
      'تواصل معنا عبر WhatsApp أو نموذج الطلب لتحديد باقة الترخيص المناسبة.',
      'تزويدنا باسم التطبيق والشعار والألوان لتخصيص الهوية التجارية.',
      'استلام النسخة التجريبية للمراجعة ثم استلام الحزمة النهائية وتوجيهات النشر.',
    ],
    purchaseStepsEn: [
      'Contact our team via WhatsApp or the inquiry form to select your license tier.',
      'Share your brand name, logo, and palette for white-label customization.',
      'Review the staging APK build, then receive your final release package.',
    ],
    hasInteractiveVideoPreview: true,
    screens: [
      {
        id: 'overview',
        titleAr: 'لوحة الأداء المالي',
        titleEn: 'Executive Revenue Dashboard',
        subtitleAr: 'ملخص المبيعات اليومية وصافي الأرباح والتدفق النقدي',
        subtitleEn: 'Daily sales summary, net profit, and cashflow pulse',
        metrics: [
          { labelAr: 'إيرادات الشهر', labelEn: 'Monthly Revenue', value: '$48,250' },
          { labelAr: 'الفواتير المسددة', labelEn: 'Paid Invoices', value: '142' },
        ],
        highlightsAr: ['نمو 18% مقارنة بالشهر الماضي', '3 فواتير بانتظار التحصيل', 'تقرير ضريبي جاهز للتصدير'],
        highlightsEn: ['+18% revenue vs prior month', '3 pending client settlements', 'Export-ready tax ledger'],
      },
      {
        id: 'invoices',
        titleAr: 'إدارة الفواتير السريعة',
        titleEn: 'Instant Invoice Builder',
        subtitleAr: 'إنشاء وإرسال فاتورة احترافية خلال 20 ثانية',
        subtitleEn: 'Create and dispatch branded invoices in 20 seconds',
        metrics: [
          { labelAr: 'فاتورة #4509', labelEn: 'Invoice #4509', value: '$2,400' },
          { labelAr: 'حالة السداد', labelEn: 'Status', value: 'Paid' },
        ],
        highlightsAr: ['إضافة شعار الشركة تلقائيًا', 'دعم رمز QR للفاتورة', 'إرسال فوري للعميل'],
        highlightsEn: ['Automatic company stamp & logo', 'Embedded verification QR code', 'One-tap client delivery'],
      },
      {
        id: 'inventory',
        titleAr: 'مراقبة المخزون والمنتجات',
        titleEn: 'Inventory & SKU Monitor',
        subtitleAr: 'تتبع الكميات والباركود وإشعارات إعادة الطلب',
        subtitleEn: 'Live stock quantities, barcode lookup, and reorder alerts',
        metrics: [
          { labelAr: 'الأصناف النشطة', labelEn: 'Active SKUs', value: '684' },
          { labelAr: 'تنبيهات النقص', labelEn: 'Low Stock', value: '7' },
        ],
        highlightsAr: ['مسح الباركود بكاميرا الهاتف', 'تحديث تلقائي مع كل بيعة', 'جرد سريع للمستودع'],
        highlightsEn: ['Instant camera barcode scan', 'Auto-deduction per order', 'Fast warehouse cycle counts'],
      },
    ],
  },
  {
    slug: 'applixo-nexus-ai',
    nameAr: 'Nexus AI Studio',
    nameEn: 'Nexus AI Studio',
    taglineAr: 'مساعد الذكاء الاصطناعي وصناعة المحتوى الذكي',
    taglineEn: 'AI Assistant, Prompt Workspace & Smart Content Studio',
    categoryId: 'ai',
    categoryAr: 'تطبيقات الذكاء الاصطناعي',
    categoryEn: 'AI Apps',
    status: 'sold',
    featured: true,
    accentHex: '#00D9FF',
    secondaryHex: '#087BFF',
    image: '/src/assets/images/app_ai_assistant_1794951750358.jpg',
    androidVersion: 'Android 10.0 – 15.0',
    minSdk: 'API 29+',
    packageSize: '29 MB',
    architecture: 'Kotlin + Compose + Streaming SSE Client',
    shortDescAr:
      'تطبيق ذكاء اصطناعي متكامل للمحادثة الذكية، تلخيص المستندات، كتابة المحتوى، وتوليد الأفكار الإبداعية.',
    shortDescEn:
      'Intelligent Android workspace for conversational AI, document summarization, copywriting, and voice prompts.',
    fullDescAr:
      'يوفر Nexus AI Studio تجربة متطورة لتطبيقات الذكاء الاصطناعي على نظام Android مع تدفق فوري للنصوص، قوالب جاهزة للتسويق والبرمجة، ومعالجة ذكية للصوت والمستندات عبر خوادم آمنة تحمي مفاتيح التشغيل.',
    fullDescEn:
      'Nexus AI Studio delivers a sleek mobile AI suite with real-time response streaming, curated workflows for marketing and coding, voice-to-prompt input, and secure backend API proxying.',
    featuresAr: [
      'استجابة فورية متدفقة (Streaming) للنصوص والردود',
      'أكثر من 35 قالبًا احترافيًا لكتابة المحتوى والأعمال',
      'إدخال صوتي ذكي يدعم اللهجات العربية والإنجليزية',
      'سجل منظم للمحادثات مع بحث فوري وتصدير PDF',
      'بنية خادم وسيط لحماية مفاتيح الذكاء الاصطناعي',
      'واجهة داكنة مريحة للعين مع تأثيرات تفاعلية سلسة',
    ],
    featuresEn: [
      'Low-latency streaming responses with Markdown & code highlighting',
      '35+ specialized workflow templates for business and creators',
      'Multilingual voice-to-prompt dictation in Arabic & English',
      'Searchable conversation archive with clean PDF/Text export',
      'Secure server-proxy architecture protecting API credentials',
      'Refined dark-first interface with smooth haptic feedback',
    ],
    requirementsAr: [
      'نظام Android 10.0 أو أحدث',
      'ذاكرة وصول عشوائي 4 جيجابايت فأكثر',
      'اتصال مستقر بالإنترنت',
    ],
    requirementsEn: [
      'Android 10.0 or higher',
      '4 GB RAM recommended',
      'Active internet connection',
    ],
    purchaseStepsAr: [
      'تواصل معنا لطلب نسخة العرض وتحديد نوع الخادم أو نموذج الذكاء الاصطناعي المفضل.',
      'تخصيص الهوية والقوالب وإعداد الخادم الوسيط الآمن.',
      'استلام التطبيق جاهزًا مع وثائق الربط والتشغيل.',
    ],
    purchaseStepsEn: [
      'Reach out via WhatsApp for a live walkthrough and backend model configuration.',
      'Customize branding, prompt templates, and secure server proxy.',
      'Receive your release package with full deployment documentation.',
    ],
    hasInteractiveVideoPreview: true,
    screens: [
      {
        id: 'chat-stream',
        titleAr: 'مساحة الحوار الذكي',
        titleEn: 'Neural Prompt Workspace',
        subtitleAr: 'تحليل الأفكار وتوليد الخطط والنصوص لحظيًا',
        subtitleEn: 'Real-time reasoning, planning, and content drafting',
        metrics: [
          { labelAr: 'زمن الاستجابة', labelEn: 'First Token', value: '0.4s' },
          { labelAr: 'القوالب الجاهزة', labelEn: 'Templates', value: '36' },
        ],
        highlightsAr: ['دعم صياغة المحتوى العربي الفصيح', 'حفظ تلقائي لسياق المشروع', 'نسخ ومشاركة بضغطة واحدة'],
        highlightsEn: ['Natural Arabic & English fluency', 'Context-aware session memory', 'One-tap copy & share'],
      },
      {
        id: 'voice-wave',
        titleAr: 'المساعد الصوتي المباشر',
        titleEn: 'Voice Wave Assistant',
        subtitleAr: 'تحويل الأفكار الصوتية إلى مستندات ومهام',
        subtitleEn: 'Convert spoken notes into structured briefs & action plans',
        metrics: [
          { labelAr: 'دقة التعرف', labelEn: 'Accuracy', value: '98%' },
          { labelAr: 'اللغات', labelEn: 'Languages', value: 'AR / EN' },
        ],
        highlightsAr: ['مؤشر موجات صوتية تفاعلي', 'تلخيص فوري للاجتماعات', 'تصدير سريع للملاحظات'],
        highlightsEn: ['Live spectral audio visualizer', 'Instant meeting summaries', 'Clean note export'],
      },
      {
        id: 'templates',
        titleAr: 'مكتبة القوالب الذكية',
        titleEn: 'Smart Prompt Library',
        subtitleAr: 'أدوات متخصصة للتسويق، البرمجة، والتلخيص',
        subtitleEn: 'Curated tools for marketing, coding, and executive briefs',
        metrics: [
          { labelAr: 'تصنيفات العمل', labelEn: 'Categories', value: '8' },
          { labelAr: 'توفير الوقت', labelEn: 'Time Saved', value: '4x' },
        ],
        highlightsAr: ['ملخص العقود والمقالات', 'مولد خطط المحتوى', 'مراجع صياغة البريد الرسمي'],
        highlightsEn: ['Document & brief summarizer', 'Campaign copy generator', 'Executive email polisher'],
      },
    ],
  },
  {
    slug: 'applixo-cinecut-pro',
    nameAr: 'CineCut Pro 4K',
    nameEn: 'CineCut Pro 4K',
    taglineAr: 'محرر الفيديو والصور الاحترافي بدقة 4K',
    taglineEn: 'Pro 4K Mobile Video & Color Grading Studio',
    categoryId: 'video-photo',
    categoryAr: 'تحرير الفيديو والصور',
    categoryEn: 'Video & Photo Editing',
    status: 'sold',
    featured: true,
    accentHex: '#F59E0B',
    secondaryHex: '#087BFF',
    image: '/src/assets/images/app_video_editor_1794951750043.jpg',
    androidVersion: 'Android 10.0 – 15.0',
    minSdk: 'API 29+',
    packageSize: '42 MB',
    architecture: 'Kotlin + Media3 Transformer + OpenGL Shaders',
    shortDescAr:
      'تطبيق مونتاج فيديو وتحرير صور عالي الأداء مع خط زمني متعدد المسارات، فلاتر لونية، وتصدير سريع حتى 4K.',
    shortDescEn:
      'Hardware-accelerated Android video & photo editor with multi-track timeline, LUT color grading, and 4K export.',
    fullDescAr:
      'يجمع CineCut Pro 4K قوة معالجة الرسوميات على Android لتقديم تجربة مونتاج سريعة وسلسة لصناع المحتوى. يضم التطبيق مسارات متعددة للفيديو والصوت، أدوات تعديل الألوان الدقيقة، انتقالات سينمائية، وتصدير خالٍ من العلامة المائية.',
    fullDescEn:
      'CineCut Pro 4K harnesses Android hardware encoding and OpenGL shaders to deliver fluid multi-track editing, precision color wheels, keyframe transitions, and watermark-free 4K rendering.',
    featuresAr: [
      'تحرير متعدد المسارات للفيديو والصوت والنصوص',
      'عجلات تصحيح الألوان الاحترافية وفلاتر LUT الجاهزة',
      'معالجة مسرّعة بالعتاد Hardware Acceleration للتصدير السريع',
      'محرر صور مدمج لتحسين الإضاءة والقص الاحترافي',
      'دعم تصدير Reels وShorts و4K بمعدلات إطارات 60fps',
      'إدارة الخطوط العربية والأجنبية المتحركة',
    ],
    featuresEn: [
      'Multi-track timeline for video, audio, overlays, and titles',
      'Precision color grading wheels and curated cinematic LUTs',
      'GPU hardware-accelerated Media3 rendering pipeline',
      'Integrated photo retouching and aspect-ratio presets',
      '60fps export tailored for Reels, Shorts, and 4K UHD',
      'Animated Arabic and Latin typography presets',
    ],
    requirementsAr: [
      'نظام Android 10.0 أو أحدث',
      'معالج يدعم تسريع الفيديو بالعتاد (64-bit)',
      'ذاكرة عشوائية 4 جيجابايت فأكثر لتصدير 4K',
    ],
    requirementsEn: [
      'Android 10.0 or higher (64-bit ARMv8)',
      'Hardware MediaCodec support',
      '4 GB+ RAM recommended for 4K exports',
    ],
    purchaseStepsAr: [
      'استعرض المواصفات وتواصل معنا عبر WhatsApp لتجربة نسخة الـ APK.',
      'اختيار باقة التخصيص (الشعار، الفلاتر الافتراضية، وخيارات التصدير).',
      'استلام النسخة النهائية الجاهزة للنشر باسم متجرك أو شركتك.',
    ],
    purchaseStepsEn: [
      'Message us on WhatsApp to request a live demo APK build.',
      'Select your brand theme, preset LUT packs, and export options.',
      'Receive your customized release build ready for Google Play.',
    ],
    hasInteractiveVideoPreview: true,
    screens: [
      {
        id: 'timeline',
        titleAr: 'الخط الزمني متعدد المسارات',
        titleEn: 'Multi-Track Timeline',
        subtitleAr: 'قص ودمج وإضافة المؤثرات بدقة الإطار الواحد',
        subtitleEn: 'Frame-accurate trimming, transitions, and audio sync',
        metrics: [
          { labelAr: 'دقة التصدير', labelEn: 'Max Output', value: '4K 60fps' },
          { labelAr: 'المسارات', labelEn: 'Tracks', value: '6 Layers' },
        ],
        highlightsAr: ['معاينة فورية بدون تقطيع', 'موجات صوتية واضحة للضبط', 'حفظ تلقائي للمشاريع'],
        highlightsEn: ['Zero-lag real-time playback', 'Visual audio waveform snapping', 'Auto-saved project drafts'],
      },
      {
        id: 'color-grade',
        titleAr: 'استوديو تصحيح الألوان',
        titleEn: 'Color Grading Lab',
        subtitleAr: 'ضبط الإضاءة والتباين وتشبع الألوان باحترافية',
        subtitleEn: 'Fine-tune exposure, temperature, shadows, and LUTs',
        metrics: [
          { labelAr: 'فلاتر LUT', labelEn: 'Curated LUTs', value: '28' },
          { labelAr: 'مؤثرات HDR', labelEn: 'Color Depth', value: '10-bit' },
        ],
        highlightsAr: ['مقارنة قبل وبعد بضغطة مطولة', 'حفظ إعدادات الألوان الخاصة بك', 'توازن ألوان سينمائي'],
        highlightsEn: ['Hold-to-compare original frame', 'Custom user color presets', 'Cinematic skin-tone protection'],
      },
    ],
  },
  {
    slug: 'applixo-krypton-chat',
    nameAr: 'Krypton Secure Chat',
    nameEn: 'Krypton Secure Chat',
    taglineAr: 'تطبيق تواصل ودردشة مشفر للفرق والمجتمعات',
    taglineEn: 'Encrypted Team Messaging & HD Calls Platform',
    categoryId: 'chat',
    categoryAr: 'التواصل والدردشة',
    categoryEn: 'Chat & Communication',
    status: 'sold',
    featured: true,
    accentHex: '#16D65A',
    secondaryHex: '#087BFF',
    image: '/src/assets/images/app_chat_comm_1794951751290.jpg',
    androidVersion: 'Android 9.0 – 15.0',
    minSdk: 'API 28+',
    packageSize: '27 MB',
    architecture: 'Kotlin + WebSockets + WebRTC + E2EE',
    shortDescAr:
      'منصة تواصل فورية مشفرة للمؤسسات والفرق تضم المحادثات الفردية والجماعية والمكالمات الصوتية والمرئية عالية الجودة.',
    shortDescEn:
      'High-speed encrypted communication platform featuring group channels, voice notes, and HD WebRTC calls.',
    fullDescAr:
      'تطبيق Krypton Secure Chat يتيح للشركات والمنصات إطلاق شبكة تواصل خاصة وآمنة على Android مع تشفير طرف إلى طرف، قنوات عمل منظمة، مشاركة ملفات سريعة، ومكالمات صوتية ومرئية مستقرة.',
    fullDescEn:
      'Krypton Secure Chat enables enterprises and communities to launch a private, responsive messaging network on Android with encrypted channels, file sharing, and crisp WebRTC voice/video calls.',
    featuresAr: [
      'محادثات فورية فردية وجماعية عبر WebSockets بزمن وصول منخفض',
      'مكالمات صوتية ومرئية عالية الدقة عبر WebRTC',
      'تشفير متقدم للرسائل والملفات المرفقة',
      'إرسال رسائل صوتية ومشاركة المستندات والصور بضغط ذكي',
      'إشعارات فورية موثوقة عبر Firebase Cloud Messaging',
      'بنية جاهزة للربط مع خوادم الشركة الخاصة',
    ],
    featuresEn: [
      'Low-latency 1:1 and group channels over persistent WebSockets',
      'HD audio and video calling powered by WebRTC',
      'End-to-end encryption for messages and attachments',
      'Crisp voice notes and smart-compressed media sharing',
      'Reliable push notifications via FCM',
      'Self-hostable backend integration for enterprise control',
    ],
    requirementsAr: [
      'نظام Android 9.0 أو أحدث',
      'خادم استضافة لخدمة الرسائل والإشعارات',
      'اتصال بالإنترنت (Wi-Fi / 4G / 5G)',
    ],
    requirementsEn: [
      'Android 9.0 or higher',
      'Backend server environment for messaging & signaling',
      'Wi-Fi, 4G, or 5G network connectivity',
    ],
    purchaseStepsAr: [
      'اضغط على طلب السعر عبر WhatsApp لمناقشة عدد المستخدمين وخطة الاستضافة.',
      'إعداد عرض السعر التفصيلي وجدول التخصيص الكامل.',
      'تجهيز الخادم والتطبيق وإطلاقهما بهوية مؤسستك.',
    ],
    purchaseStepsEn: [
      'Request pricing via WhatsApp based on user scale and hosting preferences.',
      'Receive a tailored quote covering white-label branding and server setup.',
      'Deploy both Android app and messaging server under your brand.',
    ],
    hasInteractiveVideoPreview: false,
    screens: [
      {
        id: 'channels',
        titleAr: 'المحادثات والقنوات المنظمة',
        titleEn: 'Encrypted Team Channels',
        subtitleAr: 'تصنيف سريع لمجموعات العمل والرسائل المباشرة',
        subtitleEn: 'Organized project groups, direct threads, and read receipts',
        metrics: [
          { labelAr: 'سرعة التسليم', labelEn: 'Delivery', value: '< 45ms' },
          { labelAr: 'التشفير', labelEn: 'Security', value: 'AES-256' },
        ],
        highlightsAr: ['بحث فوري داخل الرسائل والملفات', 'تثبيت الرسائل المهمة', 'كتم وإدارة الإشعارات'],
        highlightsEn: ['Instant full-text search', 'Pinned team announcements', 'Granular mute controls'],
      },
      {
        id: 'calls',
        titleAr: 'المكالمات الصوتية والمرئية',
        titleEn: 'HD Voice & Video Calls',
        subtitleAr: 'جودة صوت نقية حتى مع سرعات الإنترنت المتوسطة',
        subtitleEn: 'Adaptive bitrate audio & video calls on mobile networks',
        metrics: [
          { labelAr: 'دقة الفيديو', labelEn: 'Video Quality', value: '1080p' },
          { labelAr: 'التشفير', labelEn: 'Transport', value: 'DTLS-SRTP' },
        ],
        highlightsAr: ['عزل الضوضاء المحيطة', 'تبديل سلس بين الكاميرا الأمامية والخلفية', 'استهلاك منخفض للبيانات'],
        highlightsEn: ['Active background noise suppression', 'Smooth camera switching', 'Low data mode option'],
      },
    ],
  },
  {
    slug: 'applixo-aural-master',
    nameAr: 'Aural Master Hi-Fi',
    nameEn: 'Aural Master Hi-Fi',
    taglineAr: 'مشغل الصوتيات ومعادل الصوت الاحترافي للبودكاست والموسيقى',
    taglineEn: 'Hi-Fi Audio Streaming, Equalizer & Podcast App',
    categoryId: 'audio-music',
    categoryAr: 'الصوت والموسيقى',
    categoryEn: 'Audio & Music',
    status: 'sold',
    featured: false,
    accentHex: '#8B5CF6',
    secondaryHex: '#00D9FF',
    image: '/src/assets/images/app_audio_music_1794951750604.jpg',
    androidVersion: 'Android 9.0 – 15.0',
    minSdk: 'API 28+',
    packageSize: '19 MB',
    architecture: 'Kotlin + ExoPlayer (Media3) + AudioDSP',
    shortDescAr:
      'تطبيق بث وتشغيل صوتيات عالي الدقة مع معادل ترددات متعدد النطاقات، قوائم تشغيل ذكية، ودعم التشغيل في الخلفية.',
    shortDescEn:
      'Lossless Android audio and podcast player with multi-band EQ, offline caching, and Android Auto support.',
    fullDescAr:
      'صُمم Aural Master Hi-Fi لمنصات الصوتيات والموسيقى والبودكاست، حيث يوفر محرك تشغيل مستقر عبر Media3، معادل صوت احترافي، تحميل للاستماع بدون إنترنت، ودعم كامل للتحكم من شاشة القفل وAndroid Auto.',
    fullDescEn:
      'Built on Media3 ExoPlayer, Aural Master Hi-Fi delivers gapless playback, a 10-band graphic equalizer, encrypted offline downloads, and seamless lock-screen plus Android Auto controls.',
    featuresAr: [
      'تشغيل مستمر بدون فواصل Gapless Playback بدقة عالية',
      'معادل صوت احترافي من 10 نطاقات مع أوضاع جاهزة',
      'تنزيل الحلقات والمسارات للاستماع بدون إنترنت',
      'مؤقت نوم ذكي وإدارة سرعة التشغيل للبودكاست',
      'دعم Android Auto وعناصر التحكم بشاشة القفل',
      'واجهة داكنة أنيقة مع عرض طيفي تفاعلي للصوت',
    ],
    featuresEn: [
      'Gapless high-bitrate playback powered by Media3',
      '10-band equalizer with studio, bass, and vocal presets',
      'Encrypted offline downloads for travel and low-signal zones',
      'Sleep timer and variable playback speed for podcasts',
      'Full Android Auto and lock-screen media session controls',
      'Real-time spectral audio waveform visualization',
    ],
    requirementsAr: [
      'نظام Android 9.0 أو أحدث',
      'ذاكرة عشوائي 2 جيجابايت فأكثر',
      'يدعم السماعات السلكية وBluetooth عالية الدقة',
    ],
    requirementsEn: [
      'Android 9.0 or higher',
      '2 GB+ RAM',
      'Supports wired DACs and Bluetooth HD codecs',
    ],
    purchaseStepsAr: [
      'تواصل عبر WhatsApp لطلب نسخة التجربة وتفاصيل ربط مكتبة الصوتيات.',
      'تخصيص الألوان والشعار وربط مصادر البث أو التخزين.',
      'تسليم التطبيق جاهزًا للنشر مع دليل إدارة المحتوى.',
    ],
    purchaseStepsEn: [
      'Contact us via WhatsApp to test the demo build and streaming integration.',
      'Customize branding and connect your audio catalog endpoints.',
      'Receive the store-ready build and catalog setup guide.',
    ],
    hasInteractiveVideoPreview: false,
    screens: [
      {
        id: 'player',
        titleAr: 'مشغل الصوت عالي الدقة',
        titleEn: 'Hi-Fi Spectral Player',
        subtitleAr: 'عرض طيفي تفاعلي وتحكم دقيق في المسارات',
        subtitleEn: 'Live waveform spectrum and precision playback scrubbing',
        metrics: [
          { labelAr: 'الدقة الصوتية', labelEn: 'Audio Spec', value: '24-bit' },
          { labelAr: 'نطاقات المعادل', labelEn: 'EQ Bands', value: '10 Bands' },
        ],
        highlightsAr: ['تنقل سلس بين المسارات', 'دعم كلمات الأغاني أو نصوص البودكاست', 'حفظ آخر نقطة استماع'],
        highlightsEn: ['Instant queue reordering', 'Synced transcript/lyrics view', 'Cross-session playback resume'],
      },
    ],
  },
  {
    slug: 'applixo-focusflow-tasks',
    nameAr: 'FocusFlow Planner',
    nameEn: 'FocusFlow Planner',
    taglineAr: 'تطبيق تنظيم المهام والوقت ومؤقت التركيز الذكي',
    taglineEn: 'Daily Task Planner, Calendar & Deep Focus Timer',
    categoryId: 'tools-productivity',
    categoryAr: 'الأدوات والإنتاجية',
    categoryEn: 'Tools & Productivity',
    status: 'sold',
    featured: true,
    accentHex: '#16D65A',
    secondaryHex: '#00D9FF',
    image: '/src/assets/images/app_productivity_tasks_1794951751526.jpg',
    androidVersion: 'Android 9.0 – 15.0',
    minSdk: 'API 28+',
    packageSize: '15 MB',
    architecture: 'Kotlin + Compose + Room DB + WorkManager',
    shortDescAr:
      'تطبيق إنتاجية أنيق يجمع إدارة المهام اليومية، الجدول الزمني، ومؤقت بومودورو للتركيز مع ويدجت شاشة رئيسية.',
    shortDescEn:
      'Sleek productivity app combining daily tasks, time-blocking calendar, Pomodoro focus timer, and home widgets.',
    fullDescAr:
      'يساعد FocusFlow Planner المستخدمين على إنجاز مهامهم بكفاءة عبر تقسيم اليوم إلى فترات عمل واضحة، مع تتبع العادات ومؤقت التركيز العميق وتذكيرات ذكية دون تعقيد.',
    fullDescEn:
      'FocusFlow Planner helps individuals and teams execute daily priorities cleanly with structured time-blocking, habit streaks, a distraction-free focus timer, and native Android home widgets.',
    featuresAr: [
      'إدارة مهام مرنة بالتصنيفات والأولويات والمواعيد النهائية',
      'مؤقت تركيز عميق (Pomodoro) مع إحصائيات الإنجاز الأسبوعية',
      'جدول زمني يومي وأسبوعي بتصميم مريح للعين',
      'ويدجت تفاعلي للشاشة الرئيسية على Android',
      'يعمل بالكامل دون الحاجة للاتصال الدائم بالإنترنت',
      'دعم التصدير والنسخ الاحتياطي المحلي والسحابي',
    ],
    featuresEn: [
      'Structured task lists with priorities, tags, and deadlines',
      'Built-in Pomodoro deep work timer with weekly productivity charts',
      'Clean daily and weekly calendar time-blocking view',
      'Interactive Android home screen widgets',
      '100% offline capable with optional encrypted backup',
      'Bilingual Arabic & English support',
    ],
    requirementsAr: [
      'نظام Android 9.0 أو أحدث',
      'ذاكرة وصول عشوائي 2 جيجابايت فأكثر',
      'مساحة 50 ميجابايت فقط',
    ],
    requirementsEn: [
      'Android 9.0 or higher',
      '2 GB+ RAM',
      '50 MB storage footprint',
    ],
    purchaseStepsAr: [
      'تواصل عبر WhatsApp لطلب التطبيق وتحديد التخصيصات المطلوبة.',
      'تعديل الهوية والألوان وإضافة اسم شركتك أو مشروعك.',
      'تسليم حزمة APK / AAB جاهزة للنشر.',
    ],
    purchaseStepsEn: [
      'Message us via WhatsApp to preview and order your branded build.',
      'Customize app icon, theme colors, and store metadata.',
      'Receive release-ready APK/AAB files.',
    ],
    hasInteractiveVideoPreview: true,
    screens: [
      {
        id: 'focus',
        titleAr: 'مؤقت التركيز العميق',
        titleEn: 'Deep Focus Session',
        subtitleAr: 'جلسات تركيز مؤقتة مع متابعة المهام الحالية',
        subtitleEn: 'Timed work intervals paired with your active task queue',
        metrics: [
          { labelAr: 'جلسة اليوم', labelEn: 'Focus Today', value: '2h 40m' },
          { labelAr: 'المهام المنجزة', labelEn: 'Completed', value: '9 / 11' },
        ],
        highlightsAr: ['إيقاف مؤقت وتبديل مرن', 'تنبيهات هادئة عند انتهاء الجلسة', 'تقرير أسبوعي للإنجاز'],
        highlightsEn: ['Flexible pause & session logs', 'Gentle completion chimes', 'Weekly completion summary'],
      },
    ],
  },
  {
    slug: 'applixo-smartkit-scan',
    nameAr: 'SmartKit Pro Utility',
    nameEn: 'SmartKit Pro Utility',
    taglineAr: 'حزمة الأدوات الذكية وماسح المستندات وفحص الشبكة',
    taglineEn: 'Smart Utility Toolkit, OCR Scanner & Network Diagnostics',
    categoryId: 'tools-productivity',
    categoryAr: 'الأدوات والإنتاجية',
    categoryEn: 'Tools & Productivity',
    status: 'sold',
    featured: false,
    accentHex: '#00D9FF',
    secondaryHex: '#087BFF',
    image: '/src/assets/images/app_smart_tools_1794951752329.jpg',
    androidVersion: 'Android 10.0 – 15.0',
    minSdk: 'API 29+',
    packageSize: '21 MB',
    architecture: 'Kotlin + CameraX + ML Kit OCR',
    shortDescAr:
      'تطبيق أدوات ذكية يجمع ماسح المستندات PDF مع استخراج النصوص، قارئ QR، ومراقب سرعة الشبكة والذاكرة.',
    shortDescEn:
      'All-in-one Android utility combining PDF document scanning with OCR, QR reader, Wi-Fi speed diagnostics, and storage analyzer.',
    fullDescAr:
      'حزمة أدوات متكاملة تغني المستخدم عن تثبيت عدة تطبيقات منفصلة: مسح ضوئي احترافي للمستندات وتحويلها إلى PDF، قراءة رموز QR بأمان، قياس سرعة الشبكة، وتحليل مساحة التخزين بدقة.',
    fullDescEn:
      'SmartKit Pro Utility consolidates everyday essentials into one sleek Android app: crisp edge-detected PDF scanning with OCR text extraction, safe QR scanning, live network diagnostics, and storage breakdown.',
    featuresAr: [
      'ماسح مستندات ذكي بتحديد الحواف التلقائي عبر CameraX',
      'استخراج النصوص من الصور (OCR) وتحويلها لملفات PDF',
      'قارئ ومولد رموز QR وباركود سريع وآمن',
      'فحص سرعة الشبكة وزمن الاستجابة Ping',
      'محلل دقيق للملفات الكبيرة ومساحة التخزين',
    ],
    featuresEn: [
      'Auto edge-detection document scanner via CameraX',
      'On-device OCR text extraction and multi-page PDF export',
      'Fast, link-verified QR & barcode scanner/generator',
      'Live Wi-Fi speed and latency diagnostics',
      'Visual storage analyzer for large files and caches',
    ],
    requirementsAr: [
      'نظام Android 10.0 أو أحدث',
      'كاميرا خلفية بتركيز تلقائي للمسح الضوئي',
    ],
    requirementsEn: [
      'Android 10.0 or higher',
      'Autofocus rear camera for document scanning',
    ],
    purchaseStepsAr: [
      'التطبيق في المرحلة النهائية من الاختبار وسيتوفر قريبًا.',
      'يمكنك حجز نسختك المخصصة مسبقًا عبر WhatsApp.',
    ],
    purchaseStepsEn: [
      'Currently in final QA and releasing soon.',
      'Reserve your white-label license early via WhatsApp.',
    ],
    hasInteractiveVideoPreview: false,
    screens: [
      {
        id: 'toolkit',
        titleAr: 'مركز الأدوات الذكية',
        titleEn: 'Unified Utility Hub',
        subtitleAr: 'وصول سريع لجميع أدوات الفحص والمسح الضوئي',
        subtitleEn: 'Quick access to OCR scan, QR, network, and storage tools',
        metrics: [
          { labelAr: 'سرعة الشبكة', labelEn: 'Wi-Fi Speed', value: '780 Mbps' },
          { labelAr: 'المساحة المتاحة', labelEn: 'Storage', value: '68% Used' },
        ],
        highlightsAr: ['تحويل فوري إلى PDF عالي الدقة', 'كشف تلقائي للروابط المشبوهة في QR', 'واجهة داكنة موحدة'],
        highlightsEn: ['Instant crisp PDF output', 'Safe QR URL preview', 'Clean dark diagnostic UI'],
      },
    ],
  },
  {
    slug: 'applixo-codelingo-edu',
    nameAr: 'CodeLingo Academy',
    nameEn: 'CodeLingo Academy',
    taglineAr: 'تطبيق تعليم البرمجة واللغات التفاعلي',
    taglineEn: 'Interactive Coding & Language Learning App',
    categoryId: 'misc',
    categoryAr: 'تطبيقات متنوعة',
    categoryEn: 'Miscellaneous',
    status: 'sold',
    featured: false,
    accentHex: '#087BFF',
    secondaryHex: '#16D65A',
    image: '/src/assets/images/app_edu_learning_1794951753409.jpg',
    androidVersion: 'Android 9.0 – 15.0',
    minSdk: 'API 28+',
    packageSize: '22 MB',
    architecture: 'Kotlin + Jetpack Compose + Room',
    shortDescAr:
      'منصة تعليمية تفاعلية للمؤسسات والمدربين تضم مسارات دروس متدرجة، اختبارات ذكية، وتتبع تقدم المتعلم.',
    shortDescEn:
      'Interactive mobile learning platform for academies and creators featuring structured tracks, quizzes, and progress rings.',
    fullDescAr:
      'تطبيق CodeLingo Academy مصمم للأكاديميات ومنصات التدريب لإطلاق تجربة تعلم ممتعة على Android، مع مسارات تعليمية منظمة، اختبارات تفاعلية فورية، وحلقات تتبع التقدم اليومي.',
    fullDescEn:
      'CodeLingo Academy equips training academies and educators with a polished Android learning experience featuring step-by-step modules, interactive quizzes, and visual progress tracking.',
    featuresAr: [
      'تنظيم الدروس في وحدات ومسارات متدرجة',
      'اختبارات تفاعلية وتحديات برمجية ولغوية مع تصحيح فوري',
      'مؤشرات تقدم يومية وأسبوعية لتحفيز المتعلمين',
      'دعم تحميل الدروس للمراجعة بدون إنترنت',
      'واجهة حديثة مريحة للقراءة تدعم العربية والإنجليزية',
    ],
    featuresEn: [
      'Modular curriculum tracks with step-by-step lessons',
      'Interactive quizzes and code/language exercises with instant feedback',
      'Visual progress rings and completion milestones',
      'Offline lesson caching for uninterrupted study',
      'Clean typography supporting Arabic and English content',
    ],
    requirementsAr: [
      'نظام Android 9.0 أو أحدث',
      'ذاكرة عشوائية 2 جيجابايت فأكثر',
    ],
    requirementsEn: [
      'Android 9.0 or higher',
      '2 GB+ RAM',
    ],
    purchaseStepsAr: [
      'تواصل عبر WhatsApp لمعرفة باقات التخصيص وربط المحتوى التعليمي الخاص بك.',
      'تخصيص الهوية وإضافة مناهجك التعليمية.',
      'تسليم التطبيق جاهزًا للإطلاق على المتجر.',
    ],
    purchaseStepsEn: [
      'Connect via WhatsApp to discuss branding and curriculum import.',
      'Customize theme, modules, and academy identity.',
      'Launch your branded Android academy app.',
    ],
    hasInteractiveVideoPreview: false,
    screens: [
      {
        id: 'lessons',
        titleAr: 'مسار التعلم التفاعلي',
        titleEn: 'Interactive Lesson Track',
        subtitleAr: 'متابعة التقدم والاختبارات السريعة في شاشة واحدة',
        subtitleEn: 'Track completion rings and solve interactive exercises',
        metrics: [
          { labelAr: 'نسبة الإنجاز', labelEn: 'Completion', value: '80%' },
          { labelAr: 'الاختبارات', labelEn: 'Quizzes', value: '24 Modules' },
        ],
        highlightsAr: ['تصحيح فوري للإجابات', 'حفظ تلقائي لآخر درس', 'تصميم مشجع على الاستمرار'],
        highlightsEn: ['Instant answer verification', 'Auto-resume last lesson', 'Distraction-free study cards'],
      },
    ],
  },
];
