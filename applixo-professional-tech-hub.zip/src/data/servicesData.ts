export interface ServiceItem {
  id: string;
  number: string;
  iconName: 'Store' | 'Code2' | 'RefreshCw' | 'Layers' | 'Cpu' | 'ShieldCheck';
  titleAr: string;
  titleEn: string;
  shortDescAr: string;
  shortDescEn: string;
  detailsAr: string;
  detailsEn: string;
  deliverablesAr: string[];
  deliverablesEn: string[];
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'ready-apps',
    number: '01',
    iconName: 'Store',
    titleAr: 'بيع تطبيقات Android الجاهزة',
    titleEn: 'Ready-Made Android Apps',
    shortDescAr: 'تطبيقات متكاملة جاهزة للإطلاق الفوري بهويتك التجارية مع الكود المصدري أو النسخة المخصصة.',
    shortDescEn: 'Production-ready Android applications ready for immediate launch under your brand with clean source options.',
    detailsAr:
      'نوفر مجموعة مختارة من تطبيقات Android المبنية بأعلى معايير الجودة، الجاهزة للتخصيص السريع وإعادة التسمية باسم علامتك التجارية ورفعها على Google Play خلال أيام.',
    detailsEn:
      'We offer a curated suite of engineered Android apps built to clean architecture standards, ready for fast white-label branding and Google Play deployment in days.',
    deliverablesAr: [
      'تخصيص الهوية والشعار والألوان بالكامل',
      'ربط الإعدادات الأساسية واللوحات حسب الباقة',
      'ملف APK / AAB جاهز للنشر على Google Play',
      'دليل استخدام وتوثيق تقني واضح',
    ],
    deliverablesEn: [
      'Full brand identity, logo, and theme customization',
      'Core configuration and environment setup per license',
      'Release-ready APK / AAB package for Google Play',
      'Clear technical documentation and handover guide',
    ],
  },
  {
    id: 'custom-dev',
    number: '02',
    iconName: 'Code2',
    titleAr: 'برمجة تطبيقات حسب الطلب',
    titleEn: 'Custom Android Development',
    shortDescAr: 'بناء تطبيقات Android مخصصة بالكامل من الفكرة وحتى الإطلاق باستخدام Kotlin وJetpack Compose.',
    shortDescEn: 'End-to-end custom Android engineering from concept to launch using Kotlin and Jetpack Compose.',
    detailsAr:
      'نحول فكرتك الخاصة إلى تطبيق Android متكامل مصمم خصيصًا لنموذج عملك، مع بنية برمجية قابلة للتوسع وأداء سريع واستقرار عالٍ على مختلف الأجهزة.',
    detailsEn:
      'We engineer bespoke Android applications tailored to your exact business model, delivering scalable architecture, rapid responsiveness, and device-wide stability.',
    deliverablesAr: [
      'تحليل المتطلبات ورسم خريطة الشاشات',
      'برمجة Native باستخدام Kotlin وClean Architecture',
      'تكامل كامل مع واجهات البرمجة APIs وقواعد البيانات',
      'اختبار شامل للأداء والتوافق قبل التسليم',
    ],
    deliverablesEn: [
      'Requirement analysis and user flow architecture',
      'Native engineering with Kotlin and Clean Architecture',
      'Seamless REST/GraphQL APIs and backend integration',
      'Comprehensive performance and device QA before handover',
    ],
  },
  {
    id: 'app-modernization',
    number: '03',
    iconName: 'RefreshCw',
    titleAr: 'تطوير وتحديث التطبيقات',
    titleEn: 'App Modernization & Upgrades',
    shortDescAr: 'ترقية التطبيقات الحالية، تحسين السرعة، معالجة الأخطاء، والتوافق مع أحدث إصدارات Android.',
    shortDescEn: 'Upgrading existing apps, optimizing speed, fixing issues, and targeting the latest Android SDKs.',
    detailsAr:
      'نساعدك على إحياء تطبيقك الحالي عبر تحديث الشيفرة البرمجية، التوافق مع متطلبات سياسات Google Play الحديثة، وتسريع زمن الاستجابة وتقليل استهلاك الذاكرة.',
    detailsEn:
      'Modernize legacy Android codebases to meet the latest Google Play target SDK policies, boost frame rates, reduce battery/memory footprint, and add new capabilities.',
    deliverablesAr: [
      'تحديث Target SDK والتوافق مع Android 14 / 15',
      'تحسين سرعة التشغيل ومعالجة الأعطال',
      'إعادة هيكلة الواجهات القديمة لتجربة عصرية',
      'إضافة ميزات وخدمات جديدة بسلاسة',
    ],
    deliverablesEn: [
      'Target SDK updates for Android 14 / 15 compliance',
      'Crash resolution and cold-start speed optimization',
      'UI refresh aligned with modern Material 3 patterns',
      'Seamless integration of new product modules',
    ],
  },
  {
    id: 'ui-ux',
    number: '04',
    iconName: 'Layers',
    titleAr: 'تصميم واجهات التطبيقات UI/UX',
    titleEn: 'Android UI/UX Design',
    shortDescAr: 'تصميم واجهات مستقبلية وعصرية تراعي سهولة الاستخدام والهوية البصرية ودعم العربية والإنجليزية.',
    shortDescEn: 'Modern, intuitive interfaces crafted for usability, visual distinction, and native RTL/LTR support.',
    detailsAr:
      'نصمم واجهات تفاعلية مدروسة بعناية تجمع بين الجمال البصري وسهولة التنقل، مع نماذج أولية تفاعلية ومكتبة مكونات متسقة تضمن تجربة استخدام مريحة.',
    detailsEn:
      'We craft thoughtful mobile interfaces blending visual clarity with effortless navigation, interactive prototypes, and cohesive design systems.',
    deliverablesAr: [
      'دراسة تجربة المستخدم وتدفق الشاشات',
      'نظام تصميم متكامل بالألوان والخطوط',
      'تصميم يدعم RTL وLTR باحترافية تامة',
      'ملفات تصميم جاهزة للتنفيذ البرمجي',
    ],
    deliverablesEn: [
      'User journey mapping and screen wireframing',
      'Complete color, typography, and component system',
      'Native RTL Arabic and LTR English layout parity',
      'Developer-ready interactive prototypes and specs',
    ],
  },
  {
    id: 'ai-solutions',
    number: '05',
    iconName: 'Cpu',
    titleAr: 'حلول الذكاء الاصطناعي',
    titleEn: 'AI-Powered Mobile Solutions',
    shortDescAr: 'دمج المساعدات الذكية، معالجة النصوص والصور، والأتمتة الذكية داخل تطبيقات Android.',
    shortDescEn: 'Integrating intelligent assistants, vision/text processing, and smart automation inside Android apps.',
    detailsAr:
      'نبتكر مزايا ذكية داخل تطبيقات Android تمنح المستخدمين قيمة حقيقية، مثل المساعدات التفاعلية، تلخيص المحتوى، التعرف الذكي على المستندات، وتخصيص التجربة.',
    detailsEn:
      'We integrate practical AI capabilities inside Android apps—from conversational assistants and document OCR to intelligent media workflows and smart personalization.',
    deliverablesAr: [
      'تكامل آمن مع نماذج الذكاء الاصطناعي السحابية',
      'معالجة ذكية للنصوص والصور والصوت',
      'تحكم كامل في الخصوصية وتكاليف الاستهلاك',
      'واجهات تفاعلية سريعة الاستجابة',
    ],
    deliverablesEn: [
      'Secure server-proxied AI model integrations',
      'Intelligent text, vision, and voice workflows',
      'Quota controls, caching, and privacy safeguards',
      'Low-latency streaming user experiences',
    ],
  },
  {
    id: 'support-maintenance',
    number: '06',
    iconName: 'ShieldCheck',
    titleAr: 'الدعم الفني والصيانة حسب الاتفاق',
    titleEn: 'Support & Maintenance by Agreement',
    shortDescAr: 'متابعة تقنية مستمرة، تحديثات أمان، وإضافات دورية وفق اتفاقيات مرنة تناسب مشروعك.',
    shortDescEn: 'Ongoing technical oversight, security updates, and scheduled enhancements under flexible agreements.',
    detailsAr:
      'نبقى بجانبك بعد الإطلاق لضمان استقرار التطبيق وتحديثه وفق متطلبات الأنظمة الجديدة، مع باقات دعم وصيانة مرنة يتم الاتفاق عليها بما يلائم حجم مشروعك.',
    detailsEn:
      'We stay by your side post-launch to maintain stability and keep pace with OS updates through transparent, custom-agreed support and maintenance plans.',
    deliverablesAr: [
      'مراقبة الأداء ومعالجة الملاحظات الطارئة',
      'تحديث المكتبات والاعتماديات البرمجية',
      'دعم إطلاق الإصدارات الجديدة على المتجر',
      'خطط دعم مرنة شهرية أو حسب المشروع',
    ],
    deliverablesEn: [
      'Performance monitoring and rapid issue resolution',
      'Dependency and security patch updates',
      'Release management for new store versions',
      'Flexible monthly or milestone-based support terms',
    ],
  },
];
