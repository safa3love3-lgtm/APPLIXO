export interface TestimonialItem {
  id: string;
  isSample: boolean;
  clientNameAr: string;
  clientNameEn: string;
  roleAr: string;
  roleEn: string;
  countryAr: string;
  countryEn: string;
  avatar: string;
  appNameAr: string;
  appNameEn: string;
  appSlug: string;
  appThumbnail: string;
  rating: number;
  reviewAr: string;
  reviewEn: string;
  dateAr: string;
  dateEn: string;
}

/**
 * Sample / illustrative testimonial cards representing regional use cases.
 * Each card is clearly marked `isSample: true` ("تجربة تجريبية" / "Sample Experience")
 * until replaced with verified client testimonials with explicit client permission.
 */
export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    id: 'sample-eg-01',
    isSample: true,
    clientNameAr: 'طارق المنصور',
    clientNameEn: 'Tarek El-Mansour',
    roleAr: 'مؤسس شركة تجارة وتوزيع',
    roleEn: 'Founder, Commercial Distribution',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    avatar: '/src/assets/images/avatar_client_1_1794951753754.jpg',
    appNameAr: 'BizPulse ERP',
    appNameEn: 'BizPulse ERP',
    appSlug: 'applixo-bizpulse-erp',
    appThumbnail: '/src/assets/images/app_business_erp_1794951748767.jpg',
    rating: 5,
    reviewAr:
      'نموذج توضيحي لتجربة عميل: سهولة إصدار الفواتير ومتابعة المبيعات من الهاتف باللغة العربية ساعدت فريق المبيعات الميداني على تقليل الوقت الإداري وتنظيم التقارير اليومية.',
    reviewEn:
      'Illustrative sample experience: Issuing Arabic/English invoices and tracking daily sales directly from Android streamlined field operations and cut daily reporting delays.',
    dateAr: 'أكتوبر 2026',
    dateEn: 'October 2026',
  },
  {
    id: 'sample-sa-02',
    isSample: true,
    clientNameAr: 'نورة القحطاني',
    clientNameEn: 'Noura Al-Qahtani',
    roleAr: 'مديرة منصة محتوى رقمي',
    roleEn: 'Digital Media Platform Lead',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    avatar: '/src/assets/images/avatar_client_2_1794951753092.jpg',
    appNameAr: 'Nexus AI Studio',
    appNameEn: 'Nexus AI Studio',
    appSlug: 'applixo-nexus-ai',
    appThumbnail: '/src/assets/images/app_ai_assistant_1794951750358.jpg',
    rating: 5,
    reviewAr:
      'نموذج توضيحي لتجربة عميل: تخصيص تطبيق الذكاء الاصطناعي بهويتنا الخاصة تم بسلاسة، والواجهة السريعة باللغتين منحت مستخدمينا تجربة عصرية واضحة.',
    reviewEn:
      'Illustrative sample experience: White-labeling the AI studio app with our visual identity went smoothly, giving our mobile audience a fast bilingual workspace.',
    dateAr: 'سبتمبر 2026',
    dateEn: 'September 2026',
  },
  {
    id: 'sample-ae-03',
    isSample: true,
    clientNameAr: 'خالد السويدي',
    clientNameEn: 'Khaled Al-Suwaidi',
    roleAr: 'مدير منتجات تقنية',
    roleEn: 'Technical Product Manager',
    countryAr: 'الإمارات العربية المتحدة',
    countryEn: 'United Arab Emirates',
    avatar: '/src/assets/images/avatar_client_3_1794951754394.jpg',
    appNameAr: 'Krypton Secure Chat',
    appNameEn: 'Krypton Secure Chat',
    appSlug: 'applixo-krypton-chat',
    appThumbnail: '/src/assets/images/app_chat_comm_1794951751290.jpg',
    rating: 5,
    reviewAr:
      'نموذج توضيحي لتجربة عميل: استقرار المكالمات وجودة تصميم الشاشات الداخلية جعلا التطبيق مناسبًا للتواصل الداخلي للفرق دون تعقيد في الإعداد.',
    reviewEn:
      'Illustrative sample experience: Call stability and thoughtful screen hierarchy made the encrypted messaging app an effective workspace for distributed teams.',
    dateAr: 'أغسطس 2026',
    dateEn: 'August 2026',
  },
  {
    id: 'sample-jo-04',
    isSample: true,
    clientNameAr: 'سلمى حداد',
    clientNameEn: 'Salma Haddad',
    roleAr: 'مؤسسة مبادرة تعليمية',
    roleEn: 'EdTech Initiative Founder',
    countryAr: 'الأردن',
    countryEn: 'Jordan',
    avatar: '/src/assets/images/avatar_client_4_1794951755825.jpg',
    appNameAr: 'CodeLingo Academy',
    appNameEn: 'CodeLingo Academy',
    appSlug: 'applixo-codelingo-edu',
    appThumbnail: '/src/assets/images/app_edu_learning_1794951753409.jpg',
    rating: 5,
    reviewAr:
      'نموذج توضيحي لتجربة عميل: بساطة تنظيم الوحدات التعليمية والاختبارات الفورية ساعدت على إطلاق تطبيق تدريبي متكامل في وقت قياسي وبجودة تصميم لافتة.',
    reviewEn:
      'Illustrative sample experience: Structured lesson modules and instant quizzes allowed us to launch a polished Android learning experience on an accelerated timeline.',
    dateAr: 'يوليو 2026',
    dateEn: 'July 2026',
  },
];
